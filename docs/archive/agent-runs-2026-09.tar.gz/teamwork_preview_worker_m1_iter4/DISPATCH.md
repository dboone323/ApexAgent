## 2026-08-27T17:27:21Z

You are Worker 2 for Milestone M1 Iteration 4 (Automated Test Matrix & Strict Concurrency Remediation).

Your working directory is: /Users/danielstevens/Developer/ApexAgent/.agents/teamwork_preview_worker_m1_iter4
The project workspace is: /Users/danielstevens/Developer/ApexAgent
The authoritative user request is at: /Users/danielstevens/Developer/ApexAgent/.agents/ORIGINAL_REQUEST.md
The project scope is at: /Users/danielstevens/.gemini/antigravity/brain/20b74454-bcee-4a66-baf5-d5b597ea81a8/PROJECT.md
Reviewer 1 Handoff Report: /Users/danielstevens/Developer/ApexAgent/.agents/teamwork_preview_reviewer_m1_gen4_1/handoff.md

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Testing Principle: All tests must be implemented using REAL functional code that performs real validations. NEVER use mocks, placeholders, stubs, or dummy/fake tests.

Objective:
1. Inspect `ApexAgent/Models/TurnWatchdog.swift`. Reviewer 1 discovered that `TurnWatchdog` conforms to `@unchecked Sendable` but its internal dictionary `turns: [String: WatchedTurn]` is unsynchronized, causing a data race / SIGSEGV under multi-threaded contention (e.g. in `testTurnWatchdogConcurrentLifecycleAndTouchContention`).
2. Add `private let lock = NSLock()` (or `os_unfair_lock`) to `TurnWatchdog.swift` to synchronize all reads and writes to `turns` and `timer` across `watch()`, `unwatch()`, `touch()`, `setWaitingOnHuman()`, `isWatching()`, `isWaitingOnHuman()`, `sweep()`, and `stop()`. Note: invoke `options.onStall(turn)` outside the lock to prevent any potential re-entrancy deadlock.
3. Verify strict concurrency compilation: `swift build --build-tests -Xswiftc -strict-concurrency=complete -Xswiftc -warnings-as-errors`. Verify 0 warnings and 0 errors.
4. Run `swift test --test-product ApexAgentTests` and confirm all suites (including `TurnWatchdogTests` / `testTurnWatchdogConcurrentLifecycleAndTouchContention` and `Milestone1EmpiricalChallengeTests`) pass 100%.
5. Run `swift test --test-product ApexAgentContainerTests` and `swift test --test-product ApexAgentIntelligenceTests`.
6. Record your changes, commands run, test results, and verification logs in `handoff.md` and notify the parent orchestrator via `send_message`.
