## 2026-08-28T01:15:06Z

You are worker_m2 assigned to Milestone M2 (Autonomous Multi-Agent Playbook Templates & Presets).

Working directory: /Users/danielstevens/Developer/ApexAgent/.agents/worker_m2
Read:
- /Users/danielstevens/Developer/ApexAgent/.agents/ORIGINAL_REQUEST.md
- /Users/danielstevens/Developer/ApexAgent/PROJECT.md
- /Users/danielstevens/Developer/ApexAgent/.agents/survey_explorer_2/analysis.md

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Testing Principle: All tests must be implemented using REAL functional code that performs real validations. Never use mocks, placeholders, stubs, or dummy/fake tests.

Exclusive File Ownership:
- ApexAgent/Models/CollaborationPlaybook.swift
- ApexAgent/Models/PlaybookRunner.swift
- ApexAgent/Models/BotManager.swift (collaborative playbook extensions)
- ApexAgentTests/PlaybookCollaborationTests.swift

Tasks:
1. In `ApexAgent/Models/CollaborationPlaybook.swift`:
   - Implement `CollaborationPlaybook` models, `PlaybookPresetKind` (`.fullPRReviewLoop`, `.issueToPatchPipeline`, `.weeklyStandupAndRetrospective`), `PlaybookDispatchMode` (`.sequential`, `.parallel`), `PlaybookRoleRequirement` (`.chiefOfStaff`, `.codeArchitect`, `.researcher`, `.automator`, `.generalAssistant`), `PlaybookStageDefinition`, `PlaybookExecutionStatus`, `PlaybookStageResult`, and `PlaybookDelegationEvent`.
   - Implement built-in collaboration presets:
     - **Full PR Review Loop**: Stage 1 (PR Intake / Chief of Staff), Stage 2 Parallel (Code Quality Review / Architect + Security & Dependency Review / Researcher), Stage 3 (Patch & CI Verification / Automator), Stage 4 Approval Gate (Human Approval Card), Stage 5 (Executive Summary & PR Comments / Chief of Staff).
     - **Issue-to-Patch Pipeline**: Stage 1 (Issue Triage / Chief of Staff), Stage 2 (Root Cause & Reproduction / Researcher), Stage 3 (Patch Authoring / Architect), Stage 4 (Test Execution & Benchmark / Automator), Stage 5 Approval Gate (Review & Merge Card).
     - **Weekly Standup & Retrospective**: Stage 1 Parallel (All 5 bots generate activity summaries simultaneously), Stage 2 (Synthesis, Blockers & Action Items / Chief of Staff).
   - Implement `PlaybookParticipantAssigner`: Heuristic role-to-bot mapping across the standard 5-bot roster with fallback.
2. In `ApexAgent/Models/PlaybookRunner.swift`:
   - Implement `PlaybookRunner` actor to execute playbooks end-to-end.
   - Support sequential stage dispatching and parallel turn fan-out using Swift structured concurrency (`withThrowingTaskGroup`).
   - Implement stage approval cards (`PlaybookApprovalCard`) that pause execution when `requiresApproval == true` until user/supervisor confirmation.
   - Track peer delegation events (`PlaybookDelegationEvent`) and emit live trace events to `TraceBus`.
3. In `ApexAgent/Models/BotManager.swift`:
   - Add playbook execution interfaces (`executeCollaborationPlaybook(preset:context:)`, active playbook tracking, approval card resolution).
4. In `ApexAgentTests/PlaybookCollaborationTests.swift`:
   - Write comprehensive real functional tests validating all 3 presets, participant assignment, sequential execution, parallel fan-out, approval cards pausing and resuming, and peer delegation event tracking.
5. Build and verify:
   - Run `swift build` and `swift test --filter PlaybookCollaborationTests` (and full `swift test`). Ensure zero warnings and 100% tests pass.

Write your report to /Users/danielstevens/Developer/ApexAgent/.agents/worker_m2/handoff.md and notify caller.
