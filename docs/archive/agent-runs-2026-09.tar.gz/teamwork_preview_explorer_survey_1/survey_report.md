# ApexAgent Codebase Survey Report

**Date:** 2026-08-26  
**Auditor / Explorer:** Teamwork Explorer 1  
**Scope:** ApexAgent macOS multi-bot application (`/Users/danielstevens/Developer/ApexAgent`)

---

## Executive Summary

ApexAgent is a multi-agent macOS application built in Swift 6.4 with complete strict concurrency (`SWIFT_STRICT_CONCURRENCY: complete`) targeting macOS 27.0. The architecture mirrors an advanced teammate/multi-bot system (similar to Grok Bot), featuring durable bot profiles, per-bot conversations and memory, inter-bot delegation and peer approvals, round-robin group chats with tool allowlists, background daemon mode, multi-engine model selection (Apple Foundation Models, Local Ollama, Local MLX, Cloud Gemini, Apple PCC, `fm` CLI), and extensive tool suites.

The project is configured via XcodeGen (`project.yml`) and SwiftPM (`Package.swift`), partitioning code into modular inlined frameworks (`SharedLogging`, `SharedModels`, `SharedKit`, `MCPKit`, `ApexAgentCore`, `ApexAgentIntents`), a lightweight runtime executable (`ApexAgentRuntime`), a sandbox CLI harness (`sandboxctl`), and 4 dedicated test targets (`ApexAgentTests`, `ApexAgentIntelligenceTests`, `ApexAgentContainerTests`, `ApexAgentUITests`).

---

## 1. Project Structure, Targets, Build Settings & Concurrency

### 1.1 Project & Workspace Configuration
- **XcodeGen Specification:** `project.yml` generates `ApexAgent.xcodeproj`.
- **SwiftPM Manifest:** `Package.swift` (tools-version: 6.4) mirrors the XcodeGen configuration and enables headless CLI building (`swift build -c release`, `swift test`).
- **Platform Deployment Target:** macOS 27.0.
- **Swift Version:** Swift 6.4.

### 1.2 Strict Concurrency & Compiler Settings
- **Strict Concurrency:** Set to `complete` across all targets in `project.yml` (`SWIFT_STRICT_CONCURRENCY: complete`) and `.enableUpcomingFeature("StrictConcurrency")` / `.enableExperimentalFeature("StrictConcurrency")` in `Package.swift`.
- **Experimental Language Features:** `OTHER_SWIFT_FLAGS: "$(inherited) -enable-experimental-feature Lifetimes"`.
- **Code Signing:** `CODE_SIGNING_ALLOWED: YES`, `CODE_SIGN_IDENTITY: "-"`. Ad-hoc code signing is enforced so local debug/release builds embed `ApexAgent.entitlements` (critical for `com.apple.security.virtualization` and Apple Container sandbox operations).
- **Weak-Linked System Frameworks:**
  - `FoundationModels`
  - `_FoundationModels_AppKit`
  - `_FoundationModels_SwiftUI`
  - `_Vision_FoundationModels`
  - `_CoreSpotlight_FoundationModels`
  - Dynamically resolved and probed at runtime (e.g. `dlsym` attachment checks in `AgentEngine.swift:201-205` and `/usr/bin/fm` probe in `ApexAgentApp.swift:151-175`).

### 1.3 Target Architecture Matrix

| Target Name | Type | Source Directory | Primary Purpose & Key Dependencies |
| :--- | :--- | :--- | :--- |
| **`SharedLogging`** | Framework | `Modules/SharedLogging` | Centralized OSLog logging subsystem (`SharedLogger.swift`). |
| **`SharedModels`** | Framework | `Modules/SharedModels` | Core shared SwiftData domain models (`ProjectModel`, `TaskModel`, `SprintModel`, `ReviewSession`, `CodeIssueModel`, `AgentConversation`, `ApexSuiteSchemaV1`). |
| **`SharedKit`** | Framework | `Modules/SharedKit` | Shared utilities, DTOs, and protocol definitions. |
| **`MCPKit`** | Framework | `Modules/MCPKit` | Model Context Protocol client, server listener, and types. |
| **`ApexAgentCore`** | Framework | `ApexAgent/` | Primary application logic: `AgentOrchestrator`, `BotManager`, `GroupChat`, `RoutineManager`, `Computer`, `TraceBus`, `VoiceController`, 47+ tool implementations, security sandboxes, and SwiftUI views. |
| **`ApexAgent`** | Application | `ApexAgentRuntime/` | Thin entry-point executable (`main.swift`) invoking `ApexAgentApp.main()`. Weak-links FoundationModels and bundles frameworks. |
| **`ApexAgentIntents`** | Framework | `ApexAgentIntents/` | Siri Shortcuts & App Intents integration (`AskApexAgentIntent`, `AgentSessionEntity`). |
| **`sandboxctl`** | Executable CLI | `Tools/sandboxctl/` | Entitled CLI harness to verify Apple Container VM boot outside the xctest harness. |
| **`ApexAgentTests`** | Unit Test | `ApexAgentTests/` | Headless unit and integration tests (214+ tests across 44 files). Depends on `ApexAgentCore` and `MCPKit`. |
| **`ApexAgentIntelligenceTests`** | Unit Test | `ApexAgentIntelligenceTests/` | Tests for Vision OCR, FoundationModels multimodal, benchmarks, and intelligence pipelines. Isolated from `Containerization` to eliminate CoreDevice/UniversalHID collision. |
| **`ApexAgentContainerTests`** | Unit Test | `ApexAgentContainerTests/` | Tests for `ContainerManager` and OCI container virtualization. Isolated from FoundationModels to prevent dual-load conflicts. |
| **`ApexAgentUITests`** | UI Test | `ApexAgentUITests/` | End-to-end XCUITest UI automation suite driving the real built `.app` bundle. |

---

## 2. SwiftData Schema & Persistence Models

ApexAgent uses SwiftData (`import SwiftData`) with SQLite store persistence.

### 2.1 ModelContainer Registration
In `ApexAgentApp.swift` (lines 71 & 319), the `ModelContainer` is configured with the following 12 schema types:
```swift
.modelContainer(for: [
    Conversation.self,
    Message.self,
    AgentMemory.self,
    AppPermissions.self,
    ProjectModel.self,
    TaskModel.self,
    SprintModel.self,
    CodeIssueModel.self,
    ReviewSession.self,
    Skill.self,
    Routine.self,
    BotProfile.self
])
```

### 2.2 Entity Specifications

#### 1. `BotProfile` (`ApexAgent/Models/BotProfile.swift:12-100`)
- **Attributes:**
  - `@Attribute(.unique) var id: UUID`
  - `var name: String`
  - `var title: String` (role title, e.g. "Senior Engineer")
  - `var descriptionText: String` (operational prompt rules)
  - `var avatarName: String` (SF Symbol icon)
  - `var createdAt: Date`, `var updatedAt: Date`, `var lastActiveAt: Date`
  - `var memory: String` (durable accumulated context)
  - `var isPinned: Bool` (sidebar pinning)
  - `var isChiefOfStaff: Bool` (enables live team roster injection into system prompt)
  - `var modelProviderRaw: String?` (per-bot provider override)
  - `var ollamaModelOverride: String?` (per-bot Ollama model name, e.g. "deepseek-r1:14b")
- **Computed Properties:** `modelProvider: ModelProvider?`, `systemInstructions: String`.

#### 2. `BotMemoryEntry` (`ApexAgent/Models/BotProfile.swift:104-121`)
- **Attributes:** `@Attribute(.unique) var id: UUID`, `var key: String`, `var value: String`, `var source: String`, `var createdAt: Date`, `var botProfileId: UUID`.

#### 3. `Conversation` & `Message` (`ApexAgent/Models/ConversationModel.swift:7-74`)
- **`Conversation`:** `id: UUID`, `title: String`, `createdAt: Date`, `updatedAt: Date`, `@Relationship(deleteRule: .cascade) var messages: [Message]`.
- **`Message`:** `id: UUID`, `roleRaw: String` (`"user"`, `"assistant"`, `"system"`), `content: String`, `timestamp: Date`, `conversation: Conversation?`, `@Attribute(.externalStorage) var attachmentsData: [Data]?`.

#### 4. `AgentMemory` (`ApexAgent/Models/ConversationModel.swift:88-104`)
- **Attributes:** `id: UUID`, `key: String`, `val: String`, `category: String`, `timestamp: Date`, `embeddingData: Data?`.

#### 5. `AppPermissions` (`ApexAgent/Models/ConversationModel.swift:108-137`)
- **Attributes:** `id: UUID`, `accessibilityAllowed: Bool`, `screenRecordingAllowed: Bool`, `systemAudioRecordingAllowed: Bool`, `musicFolderAllowed: Bool`, `desktopFolderAllowed: Bool`, `documentsFolderAllowed: Bool`, `downloadsFolderAllowed: Bool`.

#### 6. `Routine` (`ApexAgent/Models/Routine.swift:14-51`)
- **Attributes:**
  - `@Attribute(.unique) var name: String`
  - `var descriptionText: String` (convention: `"<BotName>: <prompt>"`)
  - `var trigger: RoutineTrigger` (`.manual`, `.timeInterval`, `.cron`, `.onError`, `.onSuccess`, `.onMessage`, `.webhook`)
  - `var scheduledMinutes: Int`
  - `var cronExpression: String?`
  - `var enabled: Bool`
  - `var createdAt: Date`, `var updatedAt: Date`
- **Execution Receipt Struct:** `RoutineRun` (`ApexAgent/Models/RoutineRun.swift:24-63`) captures execution history (`id`, `routineId`, `routineName`, `prompt`, `botId`, `trigger`, `status`, `startedAt`, `finishedAt`, `output`, `error`).

#### 7. `Skill` (`ApexAgent/Models/Skill.swift:6-37`)
- **Attributes:** `@Attribute(.unique) var name: String`, `var descriptionText: String`, `var scriptPath: String`, `var parameterSchemaJSON: String`, `var category: String`, `var enabled: Bool`, `var createdAt: Date`, `var updatedAt: Date`, `var triggerTermsJSON: String`, `var requiredCapabilitiesJSON: String`, `var version: String`.

#### 8. `DailyBriefing` & `WeeklyReflection`
- **`DailyBriefing` (`DailyBriefing.swift:30-123`):** `@Attribute(.unique) var id: UUID`, `createdAt: Date`, `source: String`, `mood: String?`, `budgetAlertStatus: String?`, `habitCompletionCount: Int`, `activePowerUp: Bool`, `taskTitlesData: Data?`, `outlookData: Data?`, `appSyncData: Data?`.
- **`WeeklyReflection` (`WeeklyReflection.swift:5-28`):** `@Attribute(.unique) var id: UUID`, `weekStartDate: Date`, `text: String`, `createdAt: Date`.

#### 9. Shared Models (`Modules/SharedModels/Models.swift`) & Versioned Schema
- Models: `ProjectModel`, `TaskModel`, `SprintModel`, `CodeIssueModel`, `ReviewSession`, `AgentMemoryEntry`, `AgentConversation`, `AgentMessage`.
- Versioned Schema: `ApexSuiteSchemaV1` (`ApexSuiteSchema.swift:4-16`) with `ApexSuiteMigrationPlan`.

---

## 3. State Management, Session Broadcasting & Concurrency Architecture

### 3.1 State Management & Observable Architecture
The application uses Swift Observation (`@Observable`) with strict MainActor isolation:

1. **`AgentOrchestrator` (`AgentOrchestrator.swift:96-1558`):**
   - `@Observable @MainActor public final class AgentOrchestrator`
   - Manages global message state, tool registry (47+ tools), tool executions with audit logging, confirmation requests, terminal outputs, and proactive project auditor.
   - Concurrency Safety: Uses `@ObservationIgnored private nonisolated(unsafe) var currentTask: Task<Void, Never>?` to retain cancellable background jobs without breaking `@Observable` property tracking.
   - Property Tracking: Avoids `didSet`/`willSet` on observable state (`messages`, `toolEvents`, `isGenerating`) to prevent SwiftUI view invalidation bugs.

2. **`BotManager` (`BotManager.swift:24-441`):**
   - `@Observable @MainActor final class BotManager`
   - Owns `BotProfile` persistence, active bot selection (`activeBotId`), per-bot session lookup (`sessions: [UUID: BotSession]`), attention tracking (`botsNeedingAttention`), and peer approval coordination (`PeerApprovalCoordinator`).
   - Default Roster: Automatically seeds 5 default bots when empty:
     1. **Apex** (General Assistant, icon: `bolt.fill`)
     2. **Chief of Staff** (Executive Coordinator, icon: `person.crop.square.fill`, `isChiefOfStaff = true`)
     3. **Code Architect** (Senior Engineer, icon: `chevron.left.forwardslash.chevron.right`)
     4. **Researcher** (Deep Research Specialist, icon: `magnifyingglass`)
     5. **Automator** (macOS System Automator, icon: `terminal.fill`)
   - Team Playbook: Imports and exports teams in JSON/Markdown (`TeamPlaybook.swift`).

3. **`BotSession` (`BotSession.swift:18-201` & `BotMessageSender.swift:7-105`):**
   - `@Observable @MainActor final class BotSession`
   - Scoped conversation context per bot. Computes dynamic `systemInstructions` that combine the bot's static prompt, durable working memory, and (for Chief of Staff) a live formatted roster of all other bots in the team.
   - Streaming Generation: `sendMessage()` spawns a Task, appends a placeholder message, streams tokens via `makeEngine()`, and updates state.

4. **`GroupChatSession` & `GroupChatManager` (`GroupChat.swift:57-485`):**
   - Manages multi-bot group chats with round-robin turn-taking.
   - Tool Governance: Uses `DefaultGroupToolAllowlist` (`web_search`, `read_file`, `list_directory`, `file_search`, `search_memory`, `store_memory`, `get_system_info`, `send_notification`) and routes mutating tools (`run_shell_command`, `write_file`, etc.) through human confirmation.

5. **`Computer` (`Computer.swift:15-176`):**
   - Structured facade over AppKit/Foundation providing filesystem access (`.apex/computer-workspace`), browser control (`openURL`), frontmost app inspection, process listing, shell execution via `/bin/zsh`, and screen takeover signaling.

6. **`ComputerUseAgent` (`ComputerUseAgent.swift:32-98`):**
   - Action dispatcher (`click`, `type`, `keyCombo`, `scroll`, `openApp`, `wait`).
   - *Observation:* `runLoop` contains a prototype turn loop (`ComputerUseAgent.swift:78-84`) waiting 1.0s per turn.

7. **`TraceBus` (`TraceBus.swift:5-70`):**
   - `@Observable final class TraceBus: @unchecked Sendable`
   - High-throughput asynchronous event bus with concurrent `DispatchQueue` and barrier writes.
   - Ring Buffer: Capped at `maxEvents = 400`.
   - Leak Prevention: `eventStream()` registers continuations in `continuations: [UUID: Continuation]` and removes them on termination via `continuation.onTermination`.

8. **`VoiceController` (`VoiceController.swift:10-275`):**
   - MainActor speech recognition (`SFSpeechRecognizer`) and TTS (`AVSpeechSynthesizer` or ElevenLabs API).
   - Pre-processes spoken output via regex markdown stripper (`stripMarkdown`).

### 3.2 Session Broadcasting & IPC Architecture

1. **`ApexGatewayServer` (`ApexGatewayServer.swift:6-224`):**
   - TCP daemon (`NWListener`) running on port 1337 (`--daemon` mode).
   - Frame Protocol: 4-byte big-endian `UInt32` payload length header + JSON encoded `GatewayAction`.
   - Broadcast Actions: `GatewayAction.stateUpdate`, `GatewayAction.requestConfirmation`.
   - Client Handlers: `GatewayAction.sendMessage`, `GatewayAction.cancelGeneration`, `GatewayAction.resolveConfirmation`.
   - Memory Management: Connections are indexed by UUID in `connections: [UUID: NWConnection]`. The `NWConnection.stateUpdateHandler` unregisters and cleans up disconnected sockets on `.failed` and `.cancelled` states.

2. **`ApexGatewayClient` (`ApexGatewayClient.swift:1-250`):**
   - Client-side NWConnection matching the gateway protocol with automatic capped reconnect logic.

3. **`CollaborativeServer` (`CollaborativeServer.swift:6-693`):**
   - LAN HTTP server on port 1337 providing live dashboard, screen streaming (`/api/screen`), and state APIs (`/api/state`).
   - Security: Token bucket rate limiter (`TokenBucket`) and RBAC permission policy (`PolicyRule`).

4. **`WebhookServer` (`WebhookServer.swift` / `WebhookReceiver.swift`):**
   - Localhost HTTP server on port 8800 receiving external triggers for `.webhook` Routines.

### 3.3 Model Registry & Multi-Backend Engine Architecture

`ModelRegistry` (`ModelRegistry.swift:18-143`) unifies all LLM providers behind a single interface:

| Provider | Enum Case | Engine Implementation | Transport Mechanism | Special Capabilities |
| :--- | :--- | :--- | :--- | :--- |
| **Apple On-Device** | `.appleOnDevice` | `NativeAppleEngine` | In-process `SystemLanguageModel.default.respond(to:)` | Zero cloud latency, on-device privacy, multimodal vision |
| **Apple PCC** | `.applePCC` | `NativeAppleEngine` | `PrivateCloudComputeLanguageModel` | Complex reasoning via Private Cloud Compute entitlement |
| **Local Ollama** | `.localOllama` | `OllamaAgentEngine` | HTTP POST `/api/chat` (port 11434) | Streaming SSE, function calling tools, per-bot model overrides (e.g. `deepseek-r1:14b`) |
| **Local MLX** | `.localMLX` | `MLXAgentEngine` | HTTP POST `/v1/chat/completions` (port 8080) | OpenAI-compatible SSE stream, local Apple Silicon MLX-LM server |
| **Cloud Gemini** | `.cloudGemini` | `CloudGeminiLanguageModel` | REST HTTP to Google Gemini API | Gemini function calling declarations (`getParsedGeminiFunctionDeclarations`) |
| **Apple `fm` CLI** | `.fmCLI` | `FMCLILanguageModel` | Subprocess piping to `/usr/bin/fm` | Direct CLI access to Apple Foundation Models |

---

## 4. Existing Test Suites & Test Matrix

The test matrix is partitioned into 4 distinct targets to prevent runtime framework loading conflicts (specifically the known macOS `CoreDevice` vs `UniversalHID` ObjC class registration conflict):

### 4.1 Test Targets Inventory

```
ApexAgent Workspace
├── ApexAgentTests (44 files, ~214 tests)
│   ├── Unit tests (AgentRegistry, Gateway, Tools, Security, Workflows, StateGraph)
│   ├── Parity tests (MultiBotParityTests, GrokBotFeatureTests, OpenMausBotPorts)
│   └── Live bot tests (LiveBotCommunicationTests — gated by APEX_LIVE_BOTS=1)
├── ApexAgentIntelligenceTests (9 files, ~53 tests)
│   ├── Vision & OCR tests (VisionTests — DetectImageTextTool, AnalyzeImageTool)
│   ├── Model & Agent Intelligence tests (AgentIntelligenceTests, ApexAgentModelTests)
│   └── Benchmarks & Power Sessions (BenchmarkTests, PowerSessionPhase1/2Tests)
├── ApexAgentContainerTests (1 file, ~3 tests)
│   └── ContainerManager lifecycle & OCI container execution tests
└── ApexAgentUITests (2 files, ~14 tests)
    ├── End-to-end UI automation (ApexAgentUITests — real app launch, AX element verification)
    └── Live agent triage (LiveAgentTriageTests — live endpoint triage, gated by APEX_LIVE_E2E=1)
```

### 4.2 Test Suite Details

1. **`ApexAgentTests` (`ApexAgentTests/`):**
   - Testing Framework: Swift Testing (`import Testing`, `@Suite`, `@Test`) and XCTest.
   - Core Areas Covered:
     - Multi-Bot Parity: `MultiBotParityTests.swift`, `MultiBotParityP2Tests.swift`, `MultiBotParityP3Tests.swift`, `BotLayerTests.swift`.
     - Tool Governance & Security: `ToolGovernanceTests.swift`, `SecurityTests.swift`, `SandboxTests.swift`, `ToolPolicy.swift`.
     - Workflows & Automation: `AutomationWorkflowTests.swift` (covers 10 built-in automation workflows).
     - Daemon & IPC: `ApexGatewayServerTests.swift`, `ApexGatewayClientTests.swift`, `CollaborativeServerTests.swift`, `DaemonAndPeerGateTests.swift`.
     - MCP Integration: `MCPResilienceTests.swift` with `mock_mcp_server.sh`.
     - Reactive State & Bus: `TraceBusTests.swift`, `TracingTests.swift`, `StateGraphTests.swift`.

2. **`ApexAgentIntelligenceTests` (`ApexAgentIntelligenceTests/`):**
   - Isolation Strategy: Links `ApexAgentCore` without linking `Containerization`. This prevents `CoreDevice.framework` from loading into the xctest process, allowing Vision and FoundationModels to execute without duplicate HID class crashes.
   - Tests: `VisionTests.swift` (OCR rendering bitmap test, multimodal image analysis), `AgentIntelligenceTests.swift`, `BenchmarkTests.swift`.

3. **`ApexAgentContainerTests` (`ApexAgentContainerTests/`):**
   - Isolation Strategy: Links `ApexAgentCore` and exercises `ContainerManager` without importing or invoking `FoundationModels`.
   - Tests: Verifies container idle states, CPU/Memory configurations, Docker Hub reference normalization (`docker.io/library/alpine:latest`), and execution error handling.

4. **`ApexAgentUITests` (`ApexAgentUITests/`):**
   - Testing Framework: `XCTest` / `XCUIApplication` (XCUITest).
   - Architecture:
     - `ApexAgentUITests.swift`: Launches the real `.app` bundle with `launchEnvironment["APEX_TEST_FAKE_ENGINE"] = "1"` for fast, deterministic, flake-free response verification. Interacts via accessibility identifiers (`chatInputField`, `sendButton`, `AgentResponse_*`). Uses native macOS `.click()` rather than `.tap()`.
     - `LiveAgentTriageTests.swift`: Connects to live endpoints with 45s timeouts, activity step tracing, and screenshot capture on timeout (`XCTAttachment`), gated behind `APEX_LIVE_E2E=1`.

### 4.3 Test Execution Matrix

- **Local / CI SwiftPM Run:**
  ```bash
  swift test --parallel --skip testBrowserAutomation --skip testRealToolsGrepAndGitMCP
  ```
- **Xcodebuild Full Suite Run:**
  ```bash
  xcodebuild test -project ApexAgent.xcodeproj -scheme ApexAgent -destination "platform=macOS"
  ```
- **Live Bot Communication Verification:**
  ```bash
  APEX_LIVE_BOTS=1 swift test --filter LiveBotCommunicationTests
  ```
- **Live UI Triage Run:**
  ```bash
  APEX_LIVE_E2E=1 xcodebuild test -project ApexAgent.xcodeproj -scheme ApexAgent -only-testing:ApexAgentUITests/LiveAgentTriageTests
  ```

---

## 5. Summary Findings & Architecture Assessment

1. **Strict Concurrency Compliance:** The entire codebase is strictly compliant with Swift 6.4 (`SWIFT_STRICT_CONCURRENCY: complete`). All stateful classes are isolated with `@MainActor` or designed thread-safe with `@unchecked Sendable` and barrier queues (`TraceBus`).
2. **Persistence Integrity:** SwiftData persistence cleanly captures 12 model types across `Conversation`, `Message`, `BotProfile`, `BotMemoryEntry`, `Routine`, `Skill`, `DailyBriefing`, `WeeklyReflection`, and `SharedModels`.
3. **Session Broadcasting & Zero Leakage:** `TraceBus` and `ApexGatewayServer` properly clean up `AsyncStream` continuations and socket connections upon stream termination or client disconnect.
4. **Multi-Model Orchestration:** `ModelRegistry`, `NativeAppleEngine`, `OllamaAgentEngine`, and `MLXAgentEngine` provide flexible on-device and local engine backends with per-bot model overrides and dynamic JSON tool schema generation.
5. **Real Functional Testing:** All test suites use real functional code paths, real SwiftData containers, and real tool invocations. Deterministic fake engines are isolated to headless UI testing, while live end-to-end paths are tested with environment gates.
