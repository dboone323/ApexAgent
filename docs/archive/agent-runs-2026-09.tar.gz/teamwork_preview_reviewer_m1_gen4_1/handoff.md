# Milestone M1 Review Report: Automated Test Matrix & Strict Concurrency Validation

## Review Summary

**Verdict**: **REQUEST_CHANGES**

---

## 1. Observation

### 1.1 Strict Concurrency Compilation
- **Command**: `swift build --build-tests -Xswiftc -strict-concurrency=complete -Xswiftc -warnings-as-errors`
- **Exit Code**: `0`
- **Output**: `Build complete! (41.44 sec)`
- **Verification**: Zero compiler warnings and zero compiler errors under Swift 6.4 strict concurrency mode (`complete`).

### 1.2 Target 1: `ApexAgentContainerTests`
- **Command**: `swift test --test-product ApexAgentContainerTests`
- **Exit Code**: `0`
- **Output**:
  ```text
  ◇ Suite "ContainerManagerTests" started.
  ✔ Test testContainerExecFailsWhenIdle() passed after 0.003 seconds.
  ✔ Test testContainerManagerDefaultState() passed after 0.003 seconds.
  ✔ Test testContainerManagerConfigurationUpdates() passed after 0.008 seconds.
  ✔ Suite "ContainerManagerTests" passed after 0.008 seconds.
  ✔ Test run with 3 tests in 1 suite passed after 0.008 seconds.
  ```
- **Verification**: 3/3 tests passed (100% pass rate).

### 1.3 Target 2: `ApexAgentIntelligenceTests`
- **Command**: `swift test --test-product ApexAgentIntelligenceTests`
- **Exit Code**: `0`
- **Output**:
  ```text
  ━ Test run with 53 tests in 10 suites passed after 121.786 seconds with 1 known issue.
  ```
- **Verification**: 53/53 tests passed across 10 suites (including live on-device generation benchmarks, dynamic tool routing, OCR vision tools, prompt injection sanitization, confirmation gating, and audit logging).

### 1.4 Target 3: `ApexAgentTests` & Concurrency Stress Discovery
- **Command**: `swift test --test-product ApexAgentTests`
- **Exit Code**: `1` (Signal Code 11 - SIGSEGV)
- **Error**:
  ```text
  ◇ Test testTurnWatchdogConcurrentLifecycleAndTouchContention() started.
  error: Process '.../swiftpm-testing-helper --test-bundle-path ...' exited with unexpected signal code 11
  ```
- **File Inspection**:
  In `ApexAgent/Models/TurnWatchdog.swift`:
  ```swift
  public final class TurnWatchdog: @unchecked Sendable {
      private let options: Options
      private var turns: [String: WatchedTurn] = [:]
      private var timer: Timer?
      ...
      public func watch(threadId: String, botId: String) {
          let at = now()
          turns[threadId] = WatchedTurn(threadId: threadId, botId: botId, startedAt: at, lastEventAt: at, waitingOnHuman: false)
      }
      public func touch(threadId: String) {
          guard var turn = turns[threadId] else { return }
          turn.lastEventAt = now()
          turns[threadId] = turn
      }
      public func sweep() {
          let at = now()
          for turn in turns.values where !turn.waitingOnHuman {
              if at - turn.lastEventAt < options.stallMs { continue }
              turns.removeValue(forKey: turn.threadId)
              options.onStall(turn)
          }
      }
  }
  ```
  `TurnWatchdog` was declared `@unchecked Sendable` without any internal synchronization (`NSLock`, `DispatchQueue`, or actor isolation) guarding `turns: [String: WatchedTurn]`. When multiple threads/tasks concurrently invoke `watch`, `touch`, `isWatching`, or `sweep`, concurrent mutation of the dictionary triggers memory corruption and a segmentation fault crash.

### 1.5 Target 4: `ApexAgentUITests`
- **Command**: `xcodebuild test-without-building -scheme ApexAgent -only-testing:ApexAgentUITests -destination platform=macOS -derivedDataPath .dd`
- **Output**: 12 tests passed, 2 live-gated tests skipped cleanly (`LiveAgentTriageTests`).

---

## 2. Findings

### [Major] Concurrency Flaw: Unsynchronized `@unchecked Sendable` in `TurnWatchdog.swift`

- **What**: `TurnWatchdog` conforms to `@unchecked Sendable` but does not synchronize read and write access to its internal state dictionary `turns: [String: WatchedTurn]`.
- **Where**: `ApexAgent/Models/TurnWatchdog.swift`, lines 29–119.
- **Why**: Multi-agent sessions, background watchdog sweeps, and concurrent sub-agent delegations calling `watch()`, `touch()`, `setWaitingOnHuman()`, and `sweep()` across cooperative tasks cause simultaneous unsynchronized dictionary mutations, leading to data races and segmentation fault crashes (SIGSEGV).
- **Suggestion**: Add `private let lock = NSLock()` to `TurnWatchdog` and guard all accesses to `turns` and `timer` inside `lock.lock()` / `defer { lock.unlock() }`, identical to the robust synchronization patterns implemented in `RepeatDetector` and `PeerApprovalCoordinator`.

---

## 3. Verified Claims

1. **Strict Concurrency Build**: `swift build --build-tests -Xswiftc -strict-concurrency=complete -Xswiftc -warnings-as-errors` passes cleanly with 0 warnings and 0 errors. Verified via independent terminal execution.
2. **Container Sandbox Tests**: `ApexAgentContainerTests` passes 3/3 tests (100% pass rate). Verified via independent execution.
3. **Intelligence & AI Benchmarks**: `ApexAgentIntelligenceTests` passes 53/53 tests across 10 suites. Verified via independent execution.
4. **Codebase Cleanliness & Fixes**:
   - Double-escaped backslash interpolation fixes in `AccessibilityControlTool.swift`, `ScreenshotTool.swift`, `RoutineManager.swift` verified.
   - Modernized `MKLocalSearch` in `DirectionsTool.swift`, `MapSearchTool.swift`, `WeatherTool.swift` verified.
   - Buffer pointer handling in `NetworkDiagnosticsTool.swift` verified.
   - Shared `mainContext` in `ApexAgentApp.swift` daemon mode verified.
5. **Integrity Verification**: No mocks, stubs, or fake test doubles were introduced. All implementations and tests execute real functional code.

---

## 4. Caveats

- In `LiveAgentTriageTests`, 2 tests are intentionally gated on `APEX_LIVE_E2E=1` for external network triage endpoints.
- In `AgentIntelligenceTests`, on-device `ConveneMeetingTool` records a known timeout issue under heavy background load on macOS 27 beta.

---

## 5. Conclusion

While Milestone M1 achieves clean Swift 6.4 strict concurrency compilation with zero warnings and 100% pass rates across `ApexAgentContainerTests` and `ApexAgentIntelligenceTests`, empirical adversarial stress testing exposed an unsynchronized mutable state in `TurnWatchdog.swift` marked `@unchecked Sendable` that crashes with SIGSEGV under concurrent multi-thread contention.

**Verdict**: **REQUEST_CHANGES** — Worker must synchronize `TurnWatchdog` state access using `NSLock` (or actor isolation) so that concurrent turn watching and sweeping is genuinely thread-safe.

---

## 6. Verification Method

1. **Verify Strict Concurrency Build**:
   ```bash
   swift build --build-tests -Xswiftc -strict-concurrency=complete -Xswiftc -warnings-as-errors
   ```
2. **Run Container & Intelligence Suites**:
   ```bash
   swift test --test-product ApexAgentContainerTests
   swift test --test-product ApexAgentIntelligenceTests
   ```
3. **Verify Concurrency Fix in `ApexAgentTests`**:
   ```bash
   swift test --test-product ApexAgentTests
   ```
