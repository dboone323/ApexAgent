# Handoff Report — Explorer 3: ApexAgent End-to-End Evaluation Survey

## 1. Observation

- **Core Subsystems Identified**:
  - `AgentOrchestrator`: `ApexAgent/AgentOrchestrator.swift:96-1474` — `@Observable @MainActor public final class AgentOrchestrator: OrchestratorProvider, ToolEventLogger`. Handles session creation, sliding window rehydration (`rehydrationWindowSize = 4`), context pruning (`contextPruningMaxChars = 500`), tool execution (`allTools`, 33 native tools), and compaction (`compactContextIfNeeded()`, threshold 12,000 chars).
  - `BotManager`: `ApexAgent/Models/BotManager.swift:24-442` — `@Observable @MainActor final class BotManager`. Manages `[BotProfile]` roster ("Apex", "Chief of Staff", "Code Architect", "Researcher", "Automator"), peer delivery gating (`peerDeliveryDecision`), session instantiations (`BotSession`), and playbooks.
  - `GroupChatManager` & `GroupChatSession`: `ApexAgent/Models/GroupChat.swift:57-486` — Round-robin turn taking (`generationOrder`, `maxTurnsPerParticipant = 3`), group context synthesis (`buildGroupContext`), and tool action execution bridge with `DefaultGroupToolAllowlist` and human confirmation for risky tools.
  - `ComputerUseAgent` & `Computer`: `ApexAgent/Models/ComputerUseAgent.swift:32-99` & `ApexAgent/Models/Computer.swift:15-176` — Execution of GUI actions (`click`, `type`, `scroll`, `openApp`) up to 15 turns and local computer workspace abstraction (`~/.apex/computer-workspace`).
  - `VoiceController`: `ApexAgent/Models/VoiceController.swift:10-275` — `SFSpeechRecognizer` STT with `AVAudioEngine` tapping and `AVSpeechSynthesizer` / `ElevenLabs` TTS with `stripMarkdown` preprocessing.
  - `RoutineManager` & `RoutineRecorder`: `ApexAgent/Models/RoutineManager.swift:18-209` & `ApexAgent/Models/RoutineRecorder.swift:76-206` — Supports `.manual`, `.timeInterval`, `.cron`, `.onError`/`.onSuccess`, and `.webhook` triggers; teach-a-task demo recorder rendering numbered step recipes (`RecipeRenderer`).
  - `TraceBus`: `ApexAgent/Models/TraceBus.swift:4-70` — Thread-safe ring buffer (400 events max), barrier queue synchronization, and `AsyncStream<TraceEvent>` streaming.

- **Safety & Resilience Mechanisms**:
  - Context window protection: 4,096 on-device token ceiling defended by 4-message rehydration, 500 char message pruning, 3,000 char tool output cap (`Tool+Logging.swift:67-70`), and max 20 tool calls per turn limit (`Tool+Logging.swift:25-36`).
  - Network timeouts: 60s timeout for Ollama (`LocalOllamaLanguageModel.swift:175`), MLX (`LocalMLXLanguageModel.swift`), and Gemini (`CloudGeminiLanguageModel.swift:220`); 15s for web searches (`WebSearchTool.swift`).
  - Stall detection: `TurnWatchdog.swift:21-104` detects inactive turns while exempting time waiting on human approval.
  - Loop detection: `RepeatDetector.swift:37-93` LRU signature repeat detector.
  - Sandbox boundaries: `AgentOrchestrator.swift:416-468` validates paths against workspace, temp dir, and `~/.apex/skills`, throwing `SecuritySandboxError`. Apple Container virtualization micro-VM managed via `ContainerManager.swift:12-522`.
  - Confirmation gating: `ApprovalPolicy.swift:15-187` enforces destructive (`rm -rf`, `mkfs`, `git push --force`, `DROP TABLE`) and sensitive (`.env`, `.ssh/`, AWS/Docker credentials, Keychain) guards that strictly outrank grants; shell command grants narrowed per-program; unattended webhook/cron runs never inherit auto-approvals.
  - Prompt injection defense: `Tool+Logging.swift:142-164` (`sanitizeForPromptInjection`) strips instruction override and role hijack patterns.
  - Credential redaction: `SecretRedactor.swift:14-123` masks API keys, PEM private keys, JWTs, and bearer tokens in logs and transcripts.

- **Logging & Telemetry Infrastructure**:
  - Structured OSLog categories: `Logger.agent`, `Logger.tools`, `Logger.security`, `Logger.provider`, `SharedLogger.*` (`com.apexagent.app` and `com.apexsuite`).
  - Instruments Signposts: `AgentSignpost.swift:28-60` emits `os_signpost` intervals (`AgentPerformance` category) with `#isolation` actor preservation.
  - Unified Spans: `Tracing.swift:18-67` (`Tracing.span()`) synchronizes Signposts, OSLog logs, and in-app TraceBus events in a single coordinator.
  - Persistent Audit Trail: `AgentAuditLog.swift:11-131` appends JSONL records with timestamps, redacted arguments, risk ratings, and policy decision attribution (`decisionSource`, `decisionRule`) to `~/Library/Application Support/ApexAgent/apexagent_audit.jsonl`.

- **Build and Test Verification**:
  - Project specification: `project.yml` and `Package.swift` configure Swift 6.4 strict concurrency (`SWIFT_STRICT_CONCURRENCY: complete`), `-enable-experimental-feature Lifetimes`, weak linking for `FoundationModels`.
  - Test suites: 4 main targets (`ApexAgentTests`, `ApexAgentIntelligenceTests`, `ApexAgentContainerTests`, `ApexAgentUITests`).
  - Exact `xcodebuild` test commands and flags verified via project metadata and execution logs in `results/`.

## 2. Logic Chain

1. From analyzing `project.yml` and `Package.swift`, the project is structured into modular local frameworks (`ApexAgentCore`, `MCPKit`, `SharedKit`, `SharedModels`, `SharedLogging`, `ApexAgentIntents`) ensuring strict boundary separation and concurrency safety under Swift 6.4.
2. From examining `AgentOrchestrator.swift`, `BotManager.swift`, `GroupChat.swift`, `Computer.swift`, `VoiceController.swift`, and `RoutineManager.swift`, the application replaces the monolithic single-agent paradigm with a full multi-bot teammate architecture supporting concurrent sessions, inter-bot delegation, group chat tool actions, and background routine execution.
3. From inspecting `ApprovalPolicy.swift`, `AgentSecurity.swift`, `Tool+Logging.swift`, `RepeatDetector.swift`, `TurnWatchdog.swift`, `SecretRedactor.swift`, and `SecuritySandboxError.swift`, safety is implemented defensively across all layers (prompt injection sanitization, token pruning, stall/loop detection, granular per-program permission narrowing, destructive/sensitive guard supremacy, and container isolation).
4. From inspecting `AgentSignposts.swift`, `Tracing.swift`, `TraceBus.swift`, and `AgentAuditLog.swift`, observability is fully unified across developer profiling (Instruments signposts), system logging (OSLog), and persistent compliance review (JSONL audit logs with rule-level decision attribution).
5. From examining `Makefile`, `project.yml`, and `results/*.log`, testing requires specific `xcodebuild` parameters (`-project ApexAgent.xcodeproj -scheme ApexAgent -derivedDataPath .dd` and targeted `-only-testing` filters) to build and validate unit, intelligence, container, and UI test bundles.

## 3. Caveats

- Live on-device Apple Foundation Models tests (`LiveBotCommunicationTests`) require `APEX_LIVE_BOTS=1` and a supported Apple Silicon Mac with Apple Intelligence enabled.
- UI tests (`ApexAgentUITests`) require active GUI window focus and macOS Accessibility / Screen Recording permissions when run interactively.
- The micro-VM virtualization container (`ContainerManager`) requires an ad-hoc signed executable with entitlements (`ApexAgent.entitlements`) to boot the VM kernel.

## 4. Conclusion

The ApexAgent codebase is fully surveyed across all four focus areas:
1. Core subsystems (`AgentOrchestrator`, `BotManager`, `GroupChatManager`, `ComputerUseAgent`, `VoiceController`, `RoutineManager`, `TraceBus`) are native Swift 6.4 implementations supporting rich multi-agent collaboration and tool execution.
2. Safety and resilience mechanisms provide multi-layered defense against context overflow, network stalls, repetitive loops, prompt injection, unauthorized file access, and credential leakage.
3. Telemetry and audit logging provide end-to-end trace capture across OSLog, Instruments signposts, in-app reactive event buses, and persistent JSONL audit trails.
4. Exact `xcodebuild` commands and environment flags are documented and ready for comprehensive evaluation.

The complete survey report is written to:
`/Users/danielstevens/Developer/ApexAgent/.agents/teamwork_preview_explorer_survey_3/survey_report.md`

## 5. Verification Method

- **Inspect Report Artifact**:
  `view_file /Users/danielstevens/Developer/ApexAgent/.agents/teamwork_preview_explorer_survey_3/survey_report.md`
- **Verify Headless Unit & Integration Tests**:
  `xcodebuild test-without-building -project ApexAgent.xcodeproj -scheme ApexAgent -destination "platform=macOS" "-only-testing:ApexAgentTests" "-only-testing:ApexAgentIntelligenceTests" "-only-testing:ApexAgentContainerTests" -derivedDataPath .dd`
- **Verify Live Bot Communication**:
  `APEX_LIVE_BOTS=1 swift test --filter LiveBotCommunicationTests`
- **Invalidation Conditions**:
  Modifications to `project.yml`, tool signatures in `ApexAgent/Tools/`, or approval policies in `ApexAgent/Security/` without updating corresponding tests.
