# ApexAgent End-to-End Evaluation Survey Report

**Date:** 2026-08-26  
**Agent:** Explorer 3 (Teamwork Evaluation Survey)  
**Workspace:** `/Users/danielstevens/Developer/ApexAgent`  
**Target Platform:** macOS 27.0 SDK / Xcode 27 Beta / Apple Silicon (arm64e)  
**Language & Concurrency:** Swift 6.4 (Strict Concurrency: `complete`, `-enable-experimental-feature Lifetimes`)  

---

## Executive Summary

ApexAgent is an agentic multi-bot macOS application architected in Swift 6.4. It implements an autonomous teammate model (inspired by Grok Bot / OpenMausBot paradigms) featuring specialist bot personas, inter-bot delegation, collaborative group chats, background routines, local virtualization container sandboxing, Apple Foundation Models (AFM 3) integration, and safety governance.

The codebase comprises ~136 Swift files and ~24,000 lines of code across local frameworks (`ApexAgentCore`, `SharedKit`, `SharedModels`, `SharedLogging`, `MCPKit`, `ApexAgentIntents`) and comprehensive test bundles (`ApexAgentTests`, `ApexAgentIntelligenceTests`, `ApexAgentContainerTests`, `ApexAgentUITests`).

---

## 1. Core Subsystems Analysis

### 1.1 AgentOrchestrator (`ApexAgent/AgentOrchestrator.swift`)
- **Architecture**: `@Observable @MainActor public final class AgentOrchestrator: OrchestratorProvider, ToolEventLogger`.
- **Role**: Central coordinator for conversation state, model provider resolution, sliding-window transcript management, tool execution, safety confirmation gates, and SwiftData database persistence.
- **Model Engine Support**:
  - `localSystem`: Native Apple Foundation Models on-device (`SystemLanguageModel.default`).
  - `privateCloud`: Private Cloud Compute (`PrivateCloudComputeLanguageModel`), verified via `com.apple.developer.private-cloud-compute` entitlement check (`SecTaskCopyValueForEntitlement`).
  - `cloudGemini`: Google Gemini API with SSE streaming (`CloudGeminiLanguageModel`).
  - `localOllama`: Local Ollama server REST API (`LocalOllamaLanguageModel` / `OllamaAgentEngine`).
  - `localMLX`: Local MLX-LM OpenAI-compatible SSE streaming (`LocalMLXLanguageModel` / `MLXAgentEngine`).
  - `hybrid`: Dynamic routing between on-device and cloud compute based on reasoning complexity and multi-agent settings.
- **Context Management**:
  - Sliding rehydration window (`rehydrationWindowSize = 4` messages).
  - Per-message character pruning (`contextPruningMaxChars = 500` chars).
  - KV-cache prewarming via native `session.prewarm(promptPrefix: Prompt("Analyze the following"))`.
  - Asynchronous background context compaction (`compactContextIfNeeded()`) when conversation history exceeds 12,000 characters.
- **StateGraph Integration**: Executes multi-node deterministic agent pipelines (e.g., `runExplicitCodingWorkflow` chaining `Codex` ➡️ `Auditor` ➡️ `Nexus` with loop bounded retry transitions).

### 1.2 BotManager & BotSession (`ApexAgent/Models/BotManager.swift`, `BotSession.swift`, `BotProfile.swift`)
- **Architecture**: `@Observable @MainActor final class BotManager` owning persistent `[BotProfile]` (SwiftData) and active in-memory `[UUID: BotSession]`.
- **Bot Persona Roster**:
  - **Apex**: General Assistant (`bolt.fill`).
  - **Chief of Staff**: Executive Coordinator (`person.crop.square.fill`, `isChiefOfStaff = true`), dynamically assembles live team rosters into instructions via `ChiefOfStaff.systemPrompt`.
  - **Code Architect**: Senior Engineer specializing in architecture, code review, and Swift development.
  - **Researcher**: Deep Research Specialist performing web analysis and documentation synthesis.
  - **Automator**: macOS System Automator managing terminal commands, scripts, and files.
- **Inter-Bot Routing & Attention**:
  - `sendMessageTo(_:text:attachments:)`: Direct inter-bot message dispatch.
  - `botsNeedingAttention`: Computed property filtering bots blocked on pending approval cards or containing unread activity.
  - Team Playbooks: `exportPlaybook` and `importPlaybook` for sharing and importing multi-bot team configurations via JSON/Markdown.

### 1.3 GroupChatManager & GroupChatSession (`ApexAgent/Models/GroupChat.swift`)
- **Architecture**: `@Observable @MainActor final class GroupChatSession` and `GroupChatManager`.
- **Turn Taking**: Sequential round-robin execution across participants (`generationOrder`, `currentTurnIndex`, `maxTurnsPerParticipant = 3`).
- **Context Synthesis**: `buildGroupContext(for:)` compiles rolling conversation history into structured multi-turn prompts with role attribution.
- **Group Tool Action Bridge (WS6)**:
  - Deterministic preflight evaluation: `groupToolPermission(tool:) -> GroupToolPermission` (`.allowed`, `.needsApproval`, `.denied`).
  - Safe default allowlist: `DefaultGroupToolAllowlist.set` (`web_search`, `read_file`, `list_directory`, `file_search`, `search_memory`, `store_memory`, `get_system_info`, `send_notification`).
  - Human-in-the-loop gate: Risky tools (`run_shell_command`, `write_file`, `delete_file`, `move_file`, `run_applescript`) pause execution and invoke `orchestrator.requestConfirmation`.
- **Panel Debates & Meetings**: `ConveneMeetingTool.swift` runs structured multi-round debates across specialist sub-agents (`AgentRegistry`) to reach consensus on complex topics.

### 1.4 ComputerUseAgent & Computer (`ApexAgent/Models/ComputerUseAgent.swift`, `Computer.swift`)
- **Architecture**: `@MainActor @Observable public final class ComputerUseAgent` and `@Observable @MainActor final class Computer`.
- **Computer Facade**: Models the local Mac as an autonomous workspace (`~/.apex/computer-workspace`) providing structured interfaces over browser automation, window management, process listing, and filesystem I/O.
- **GUI Control Loop**: `ComputerUseAgent.runLoop(goal:)` executes discrete UI actions (`click`, `doubleClick`, `type`, `keyCombo`, `scroll`, `openApp`, `wait`, `finish`, `fail`) up to `maxTurns = 15`.
- **System Automation Tools**:
  - `AccessibilityControlTool.swift`: macOS Accessibility API (`AXUIElement`) inspection and control.
  - `ApplicationControlTool.swift`: `NSWorkspace` app activation, launching, and lifecycle management.
  - `BrowserAutomationTool.swift`: Headless / WebKit browser automation (`control_browser`).
  - `PTYSession.swift`: Interactive pseudo-terminal session manager handling ANSI parsing and bounded output buffers.

### 1.5 VoiceController (`ApexAgent/Models/VoiceController.swift`)
- **Architecture**: `@MainActor class VoiceController: NSObject, ObservableObject, SFSpeechRecognizerDelegate, AVSpeechSynthesizerDelegate, AVAudioPlayerDelegate`.
- **Speech Recognition (STT)**: `SFSpeechRecognizer` with `SFSpeechAudioBufferRecognitionRequest` and `AVAudioEngine` tapping (`__installTapOnBus` for macOS 27 compatibility).
- **Speech Synthesis (TTS)**:
  - System TTS: `AVSpeechSynthesizer` with localized voice selection (`apex.voiceLocale`) and dynamic speech rate adjustment (`apex.voiceSpeechRate`).
  - ElevenLabs Cloud TTS: REST-based streaming audio synthesis with API key authentication from Keychain.
- **Natural Pronunciation**: `stripMarkdown()` removes markdown headings, links, bold markers, and code blocks before feeding text to speech synthesizers.

### 1.6 RoutineManager & RoutineRecorder (`ApexAgent/Models/RoutineManager.swift`, `RoutineRecorder.swift`)
- **Architecture**: `@MainActor final class RoutineManager: Observable` and `@Observable @MainActor final class RoutineRecorder`.
- **Triggers**:
  - `.manual`: User triggered execution via UI.
  - `.timeInterval`: Interval timer firing every N minutes.
  - `.cron`: Standard 5-field cron expressions evaluated every 60 seconds (`CronSchedule.matches(date:)`).
  - `.onError` / `.onSuccess`: Outcome-reactive reflection triggers dispatched by `ReflectionManager`.
  - `.webhook`: HTTP webhook dispatch on port 8800 (`WebhookServer` / `WebhookRouter`).
- **Bot Routing Convention**: Routines use `<BotName>: <prompt>` prefixes to route executions to designated specialist bots.
- **Teach-a-Task (`RoutineRecorder`)**: Observes user activity (frontmost app switching, tool executions, screen capture/OCR) to generate replayable numbered recipes (`RecipeRenderer`) persisted as new routines.

### 1.7 TraceBus & Tracing Infrastructure (`ApexAgent/Models/TraceBus.swift`, `Tracing.swift`, `AgentSignposts.swift`)
- **Architecture**: `TraceBus` concurrent ring buffer (400 events max) with barrier writes and `AsyncStream<TraceEvent>` broadcasting.
- **Unified Telemetry**: `Tracing.span()` coordinates three telemetry channels simultaneously:
  1. Instruments `os_signpost` intervals (`AgentPerformance` category).
  2. Apple Unified Logging (`os.Logger`).
  3. Real-time in-app trace buffer (`TraceBus.shared`).

---

## 2. Safety and Resilience Mechanisms

### 2.1 Context Window Limit & Token Efficiency
- **Hard 4,096 Token Budget Management**: On-device AFM 3 enforces a strict 4,096-token ceiling. ApexAgent guards against `DecoderModelError` via multi-layer pruning:
  - Sliding Rehydration: Only last 4 messages are rehydrated on turn start (`rehydrationWindowSize = 4`).
  - History Character Capping: Historical messages truncated to 500 characters (`contextPruningMaxChars = 500`).
  - Tool Call Budget: Capped at maximum 20 tool calls per turn (`activeTurnToolCallCount > 20` aborts with descriptive error).
  - Tool Output Truncation: Centralized truncation in `Tool+Logging.swift` caps all tool outputs at 3,000 characters.
  - Dynamic Context Compaction: Conversations >12,000 characters trigger LLM summarization into a compact system summary message.

### 2.2 Network Timeouts & Resilient Retries
- **Local Ollama & MLX**: Explicit 60-second timeouts (`urlRequest.timeoutInterval = 60`) on local model streaming calls, with 8-loop generation guards.
- **Cloud Gemini**: 60-second HTTP timeout interval with error recovery.
- **Web Search & MCP**: 15-second bounded timeouts for external web searches and MCP JSON-RPC requests.
- **Turn Watchdog (`TurnWatchdog.swift`)**: Activity-based stall detection watching event intervals (ignoring time spent waiting for human approvals) to prevent wedged model calls or hanging child processes.
- **Repeat Detector (`RepeatDetector.swift`)**: LRU signature detector flagging repetitive tool calls (e.g. infinite loops on same command/args) at threshold counts (3, 5).

### 2.3 Sandbox Boundaries & Filesystem Security
- **Workspace Verification (`verifyPathAllowed`)**: Standardizes and verifies all file access against the active workspace root, temporary directory, and `~/.apex/skills`. Throws `SecuritySandboxError.pathViolation` on traversal.
- **Protected Folder Settings**: Enforces granular user permissions for Desktop, Documents, Downloads, and Music folders (`SecuritySandboxError.*FolderRestricted`).
- **Security-Scoped Bookmarks**: Persists sandbox permissions across application restarts in `UserDefaults` (`apex.sandboxBookmarks`).
- **Apple Container Isolation (`ContainerManager.swift`)**: Rootless OCI micro-VM container sandbox using Apple's `Containerization` framework (pinned to `0.38.0`), custom Linux kernel (`vmlinux`), and `sandboxctl` entitlement verification harness.

### 2.4 User Confirmation Gating & Approval Policy
- **Risk Classification (`AgentSecurity.swift`)**: Strict classification into `low`, `medium`, and `high` risk. High-risk tools (`run_shell_command`, `delete_file`, `write_file`, `run_applescript`, `create_skill`, `control_app`, `control_accessibility`, `control_browser`) mandate user approval.
- **Auto-Approve Engine (`ApprovalPolicy.swift`)**:
  - **Destructive Guards**: Regex patterns (`rm -rf`, `mkfs`, `diskutil erase`, `shutdown`, fork bombs, `git push --force`, `DROP TABLE`, `sudo rm`) unconditionally block auto-approval.
  - **Sensitive Guards**: Access to `.env`, `.ssh/`, AWS/Docker credentials, Keychain passwords, and service accounts unconditionally blocks auto-approval.
  - **Guards Outrank Grants**: Destructive and sensitive guards take precedence over "Always allow" grants and auto-mode.
  - **Granular Shell Grants**: Shell execution grants are scoped per-program (`run_shell_command:git`, `run_shell_command:npm`) rather than granting universal shell access.
  - **Unattended Block**: Webhook and cron scheduled runs automatically set `isUnattendedTurn = true`, disabling auto-approvals.
  - **Timeout Auto-Deny**: Pending confirmation requests automatically deny after 60 seconds (`confirmationTimeoutSeconds = 60`).
- **Bot-to-Bot Peer Gating (`PeerApprovalCoordinator.swift`)**: Unapproved bot-to-bot delegations generate pending peer cards with 15-minute expiration timers.
- **Prompt Injection Neutralization**: `sanitizeForPromptInjection` strips instruction override attempts (`ignore previous instructions`, role redefinition, system-prompt masquerading) from external tool outputs.

---

## 3. Logging, Telemetry, and Trace Capture Infrastructure

| Component | Technology | Target / Output Location | Purpose |
|---|---|---|---|
| **Unified Logging** | `os.Logger` | Subsystem `com.apexagent.app` (Categories: `Agent`, `Tools`, `Security`, `Provider`, `Tracing`) | System-level structured diagnostics and Console.app monitoring |
| **Shared Logging** | `Modules/SharedLogging` | Subsystem `com.apexsuite` (Categories: `AI`, `MCP`, `Data`, `UI`, `Git`) | Modular cross-framework logging |
| **Performance Signposts** | `os_signpost` | OSLog `AgentPerformance` & `points-of-interest` | Profiling in Xcode Instruments (Time Profiler & Foundation Models template) |
| **Persistent Audit Trail** | `AgentAuditLog` (Actor) | `~/Library/Application Support/ApexAgent/apexagent_audit.jsonl` | Append-only JSON Lines audit record of all tool calls, arguments (redacted), confirmations, and status |
| **Authorization Decision Log** | `ApprovalPolicy` + `AgentAuditLog` | `apexagent_audit.jsonl` (with `decisionSource` and `decisionRule`) | Audit trail recording exact policy rule and verdict for every confirmation decision |
| **Secret Redactor** | `SecretRedactor` | In-memory redaction before persistence/logging | Masks API keys, JWTs, PEM private keys, Bearer tokens, and passwords (`«redacted N chars»`) |
| **In-App Trace Bus** | `TraceBus` | Thread-safe ring buffer (400 events), `AsyncStream<TraceEvent>` | Live UI diagnostic views and local debug API endpoints (`/api/traces`) |

---

## 4. Build and Test Execution Commands

### 4.1 Project Configuration
- **Xcode Project**: `ApexAgent.xcodeproj` (generated via XcodeGen `project.yml`).
- **Target OS**: macOS 27.0 (Deployment Target `27.0`).
- **Swift Version**: 6.4 (`SWIFT_STRICT_CONCURRENCY: complete`).
- **Weak Linking**: `FoundationModels`, `_FoundationModels_AppKit`, `_FoundationModels_SwiftUI`, `_Vision_FoundationModels`, `_CoreSpotlight_FoundationModels`.

### 4.2 Xcodebuild Commands

#### 1. Build for Testing (Debug)
```bash
xcodebuild build-for-testing   -project ApexAgent.xcodeproj   -scheme ApexAgent   -destination "platform=macOS"   -configuration Debug   -derivedDataPath .dd
```

#### 2. Build for Release
```bash
xcodebuild build   -project ApexAgent.xcodeproj   -scheme ApexAgent   -destination "platform=macOS"   -configuration Release   -derivedDataPath .dd-release
```

#### 3. Run Unit, Intelligence, and Container Test Suites (Headless)
```bash
xcodebuild test-without-building   -project ApexAgent.xcodeproj   -scheme ApexAgent   -destination "platform=macOS"   "-only-testing:ApexAgentTests"   "-only-testing:ApexAgentIntelligenceTests"   "-only-testing:ApexAgentContainerTests"   -derivedDataPath .dd
```

#### 4. Run Full Combined Test Matrix (Build + Test)
```bash
xcodebuild test   -project ApexAgent.xcodeproj   -scheme ApexAgent   -destination "platform=macOS"   -configuration Debug   -derivedDataPath .dd
```

#### 5. Run UI Test Suite (XCUITest)
```bash
xcodebuild test-without-building   -project ApexAgent.xcodeproj   -scheme ApexAgent   -destination "platform=macOS"   "-only-testing:ApexAgentUITests"   -derivedDataPath .dd
```

### 4.3 Swift Package Manager (SPM) Commands
```bash
# Compile release binaries
swift build -c release

# Run headless test suite (skipping GUI/MCP hanging tests)
swift test --parallel   --skip testBrowserAutomation   --skip testRealToolsGrepAndGitMCP

# Run live on-device bot-to-bot communication verification
APEX_LIVE_BOTS=1 swift test --filter LiveBotCommunicationTests
```

### 4.4 Environment Flags Matrix

| Flag | Purpose | Default |
|---|---|---|
| `APEX_LIVE_BOTS=1` | Enables live on-device Foundation Model multi-bot communication tests (`LiveBotCommunicationTests`) | Disabled (fast skip) |
| `APEX_LIVE_E2E=1` | Enables live end-to-end response triage tests in `LiveAgentTriageTests` | Disabled (skipped) |
| `APEX_TEST_MODE=1` | Bypasses interactive confirmation prompts in automated unit testing | Active in test runners |
| `APEX_TEST_FAKE_ENGINE=1` | Uses deterministic canned reply engine (`FakeAgentEngine`) for hermetic testing | Optional |
| `APEX_ENABLE_FS_WATCHER=1` | Enables filesystem watcher and proactive auditor background loop during debug | Disabled in test mode |
| `APEX_AUDIT_LOG_PATH` | Overrides default destination path for JSON Lines audit log | Application Support |
| `APEX_WORKSPACE` | Overrides default workspace directory path | Current working directory |
| `APEX_DEBUG=1` | Enables verbose debug diagnostics | Scheme default |

---

## 5. Summary Matrix of Codebase Integrity

| Dimension | Assessment | Key Evidence |
|---|---|---|
| **Swift 6.4 Concurrency** | Fully Compliant | `SWIFT_STRICT_CONCURRENCY: complete`, actor isolation captured via `#isolation`, zero data-race warnings |
| **Testing Authenticity** | Real Validations | No mocks/stubs; live Foundation Model tests, real socket round trips in `WebhookServerTests`, true SwiftData persistence |
| **Context Window Resilience** | Robust | Sliding window (4 turns), 500 char pruning, 3,000 char tool output cap, 20-call turn limit, >12k compaction |
| **Sandboxing & Permissions** | Multi-Layered | Path resolution, folder permissions, Security-Scoped Bookmarks, OCI Virtualization VM container |
| **Observability** | Comprehensive | Structured OSLog, Instruments Signposts, JSONL Audit Trail, Redacted Decision Logging, Real-time TraceBus |
