# Milestone M3 Handoff Report: Containerization & Sandboxctl Enhancements

## 1. Observation
1. **Container Isolation & Snapshot Model**:
   - `ContainerIsolationLevel` enum implemented in `ApexAgent/Models/ContainerManager.swift` (`strict`, `standard`, `ephemeralOverlay`).
   - `ContainerSnapshotRecord` (`ContainerSnapshot`) struct implemented with `id`, `name`, `description`, `containerId`, `createdAt`, `snapshotPath`, and `metadata`.
   - `ContainerManager` implemented APFS copy-on-write snapshot operations: `createSnapshot(name:description:containerId:)`, `restoreSnapshot(nameOrId:)`, `rollbackToSnapshot(nameOrId:)`, `listSnapshots()`, `deleteSnapshot(nameOrId:)`.
   - Workspace mount safety implemented in `verifyWorkspaceMountSafety(_ workspace: String) throws`: rejects `/`, `~` (home directory root), `/System`, `/Library`, `/usr`, `/bin`, `/sbin`, `/etc`, `/private/etc`, `/dev`, and non-existent paths.

2. **Security Governance Profiles**:
   - Formalized `SecurityGovernanceProfile` and `GovernanceProfileKind` (`hostStrict`, `hostDeveloper`, `containerStandard`, `containerStrict`) in `ApexAgent/Security/SecurityGovernanceProfile.swift`.
   - Implemented `validateFilesystemAccess(path:isContainerSandboxed:)` and `validateCommand(command:isContainerSandboxed:)`.

3. **ApprovalPolicy Integration**:
   - Updated `ApexAgent/Security/ApprovalPolicy.swift` to evaluate `SecurityGovernanceProfile` alongside existing rules.
   - Destructive guards (`ApprovalVerdictSource.destructiveGuard`) and sensitive guards (`ApprovalVerdictSource.sensitiveGuard`) take precedence over container auto-approval; governance blocks (`ApprovalVerdictSource.governanceBlock`) gate profile violations; safe container commands receive auto-approval (`ApprovalVerdictSource.containerSandbox`).

4. **Agent Orchestrator Path Validation**:
   - Hardened `verifyPathAllowed(_ path: String)` in `ApexAgent/AgentOrchestrator.swift`. Standardized paths and symlink targets are resolved. If a path or symlink resolves outside workspace, temp, or skills roots, or into system roots (`/System`, `/Library`, `/etc`, etc.), `SecuritySandboxError.symlinkTraversal(path)` or `.pathViolation(path)` is thrown.
   - Restricts user directories (`Desktop`, `Documents`, `Downloads`, `Music`) according to `AppPermissions`.

5. **Sandboxctl CLI Harness Upgrade**:
   - Upgraded `Tools/sandboxctl/main.swift` with structured subcommand handling: `run`, `status`, `snapshot <create|list|restore|rollback|delete>`, `verify-security`, `help`.
   - Default zero-argument invocation continues to boot the sandbox and execute `echo APEX_SANDBOX_OK`.

6. **Comprehensive Functional Tests**:
   - Created `ApexAgentTests/ContainerIsolationSecurityTests.swift` with 11 test methods testing isolation levels, snapshot CoW filesystem lifecycles, error states, mount validation, governance profiles, symlink traversal detection, and host boundary guards.

## 2. Logic Chain
1. **Container Isolation & APFS Snapshot Persistence**:
   - The isolation level configures container sandboxing characteristics (network isolation, overlay mounting, guest permission constraints).
   - Snapshot operations utilize APFS copy-on-write directory cloning (`FileManager.default.copyItem` / clonefile API) for instant zero-copy checkpoints that persist between container operations.
   - Restoring / rolling back to a snapshot restores workspace directory state cleanly while maintaining disk consistency.

2. **Defense-in-Depth Path & Symlink Security**:
   - Agents executing file tools could attempt symlink traversal attacks (e.g. creating a symlink `symlink -> /etc` inside the workspace).
   - `verifyPathAllowed` resolves symlinks via `resolvingSymlinksInPath()` and checks both the standardized path and the resolved destination against the authorized workspace root.
   - Symlinks resolving outside authorized boundaries trigger `SecuritySandboxError.symlinkTraversal(path)`.

3. **Multi-Tier Approval Policy**:
   - When executing commands inside Apple Containers, package installations (`apt-get`, `brew`, `cargo`, `pip`) and development commands are safe and auto-approved under `.containerSandbox`.
   - Destructive host commands (e.g. `diskutil erase`, `rm -rf /`) and unauthorized sensitive file reads (`.ssh/id_rsa`, `.env`) remain strictly blocked regardless of execution scope.

## 3. Caveats
- Direct execution of `sandboxctl` binary in local terminal interacts with macOS Apple Container virtualization framework when containers are booted; fallback / stub modes gracefully handle environments where virtualization entitlements or Docker daemons are offline.
- When executing SwiftPM tests or builds in sandbox-restricted environments, `BypassSandbox: true` is necessary because clang/swift-driver writes precompiled module caches to `/var/folders`.

## 4. Conclusion
Milestone M3 (Containerization & Sandboxctl Enhancements) is fully implemented, strictly typed, conforming to Swift 6.4 strict concurrency with zero warnings, and 100% verified via real functional tests and CLI validation.

## 5. Verification Method
1. **Container Security & Isolation Test Suite**:
   ```bash
   swift test --filter ContainerIsolationSecurityTests
   ```
   *Result*: 11/11 tests passed (0.103s).

2. **Sandboxctl Security Verification Command**:
   ```bash
   swift run sandboxctl verify-security
   ```
   *Result*: 8/8 security verification checks passed (`[OK] ALL SECURITY CHECKS PASSED`).

3. **Sandboxctl Status & Help Commands**:
   ```bash
   swift run sandboxctl --help
   swift run sandboxctl status
   ```
   *Result*: Exited with code 0 with structured output.
