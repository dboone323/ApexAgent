# Progress Log - Milestone M3 (Containerization & Sandboxctl Enhancements)

Last visited: 2026-08-27T20:50:00-05:00

## Completed Items
1. **SecurityGovernanceProfile.swift**:
   - Implemented `ExecutionScope` (`.host`, `.container`) and `GovernanceProfileKind` (`.hostStrict`, `.hostDeveloper`, `.containerStandard`, `.containerStrict`).
   - Implemented `SecurityGovernanceProfile` struct with fine-grained permissions (`allowNetwork`, `allowHostMounts`, `blockDestructiveHostCommands`, `blockSensitiveFileAccess`, `allowedToolIdentifiers`, `deniedToolIdentifiers`).
   - Implemented `validateFilesystemAccess` and `validateCommand` methods.

2. **ContainerManager.swift**:
   - Added `ContainerIsolationLevel` enum (`.strict`, `.standard`, `.ephemeralOverlay`).
   - Added `ContainerSnapshotRecord` struct (`ContainerSnapshot`).
   - Added `isolationLevel` property with UserDefaults synchronization.
   - Implemented APFS copy-on-write snapshot operations: `createSnapshot`, `restoreSnapshot`, `rollbackToSnapshot`, `listSnapshots`, `deleteSnapshot`.
   - Implemented workspace mount safety validation: `verifyWorkspaceMountSafety(_ workspace: String) throws` rejecting `/`, `~`, `/System`, `/Library`, `/etc`, `/usr`, `/bin`, etc.
   - Updated `startContainer(workspace:isolationLevel:)` to enforce mount safety and configure isolation parameters.

3. **ApprovalPolicy.swift**:
   - Integrated `SecurityGovernanceProfile` into `ApprovalPolicy.verdict` and `ApprovalPolicy.autoDecision`.
   - Prioritized destructive guards (`ApprovalVerdictSource.destructiveGuard`) and sensitive guards (`ApprovalVerdictSource.sensitiveGuard`), followed by profile validation (`ApprovalVerdictSource.governanceBlock`) and container auto-approval (`ApprovalVerdictSource.containerSandbox`).

4. **AgentOrchestrator.swift & SecuritySandboxError.swift**:
   - Strengthened `verifyPathAllowed(_ path: String)` to resolve symlinks and detect escapes outside allowed roots, throwing `SecuritySandboxError.symlinkTraversal(path)`.
   - Enforced host system root `/` and user folder restrictions (`Desktop`, `Documents`, `Downloads`, `Music`).
   - Conformed `SecuritySandboxError` to `Equatable` and `Sendable`.

5. **sandboxctl CLI Upgrade**:
   - Upgraded `Tools/sandboxctl/main.swift` to support subcommands: `run`, `status`, `snapshot <create|list|restore|rollback|delete>`, `verify-security`, `help`.
   - Kept zero-argument invocation default behavior for backward compatibility.

6. **ContainerIsolationSecurityTests.swift**:
   - Created 11 comprehensive real functional tests covering isolation levels, APFS snapshot lifecycle on disk, error handling, mount safety, governance profile evaluation, ApprovalPolicy integration, symlink traversal detection, and host boundary enforcement.
   - 100% test pass rate with zero warnings.
