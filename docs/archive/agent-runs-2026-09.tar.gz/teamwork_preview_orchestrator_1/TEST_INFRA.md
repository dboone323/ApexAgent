# E2E Test Infra: ApexAgent

## Test Philosophy
- Real functional code execution across all live backends and bot rosters.
- Zero mocks, stubs, placeholders, or dummy tests.
- Methodology: Category-Partition + Boundary Value Analysis + Pairwise Combinatorial + Real-World Workload Testing.

## Feature Inventory Mapping
| # | Feature | Source | Tier 1 (Coverage) | Tier 2 (Boundary) | Tier 3 (Cross-Feature) | Tier 4 (Real-World) |
|---|---------|--------|:-----------------:|:-----------------:|:---------------------:|:-------------------:|
| F1 | Strict Concurrency & Build Matrix | R3 | 5 | 5 | ✓ | ✓ |
| F2 | SwiftData Model Persistence | R3 | 5 | 5 | ✓ | ✓ |
| F3 | Zero Session Broadcasting Leaks | R3 | 5 | 5 | ✓ | ✓ |
| F4 | Live Bot Roster Execution | R1 | 5 | 5 | ✓ | ✓ |
| F5 | Multi-Engine Backend Dispatch | R1 | 5 | 5 | ✓ | ✓ |
| F6 | Multi-Agent Coordination & Delegation | R1 | 5 | 5 | ✓ | ✓ |
| F7 | Deep Subsystem Integrity & Function | R2 | 5 | 5 | ✓ | ✓ |
| F8 | Bot Output Quality & Token Efficiency | R2 | 5 | 5 | ✓ | ✓ |
| F9 | Safety Gating, Sandboxing & Resilience | R2 | 5 | 5 | ✓ | ✓ |
| F10 | Comprehensive E2E Verification & Adversarial | R1-R3 | 5 | 5 | ✓ | ✓ |

## Test Architecture
- SwiftPM test suites: `ApexAgentTests`, `ApexAgentIntelligenceTests`, `ApexAgentContainerTests`.
- UI Automation: `ApexAgentUITests`.
- Live integration runners: `LiveBotCommunicationTests`, `LiveAgentTriageTests`.
- Direct execution harnesses: Custom Swift scripts and test binaries executing real engine calls and multi-bot debates.
