# Project: ApexAgent Comprehensive End-to-End Evaluation

## Architecture
ApexAgent is an advanced multi-bot macOS application built in Swift 6.4 with strict concurrency (`complete`).
- **Data Persistence**: SwiftData `ModelContainer` managing 12 persistent `@Model` types (`BotProfile`, `BotMemoryEntry`, `Conversation`, `Message`, `Routine`, `Skill`, `DailyBriefing`, `WeeklyReflection`, `ProjectModel`, `TaskModel`, `SprintModel`, `ReviewSession`, `CodeIssueModel`, `AppPermissions`, `AgentMemory`).
- **Multi-Engine LLM Tier**: Unified `ModelRegistry` supporting Native Apple Foundation Models (`NativeAppleEngine`), Local Ollama (`OllamaAgentEngine`), Local MLX (`MLXAgentEngine`), `fm` CLI (`FMCLILanguageModel`), and Cloud Gemini (`CloudGeminiLanguageModel`).
- **Multi-Bot Teammate Architecture**: `BotManager` orchestrating dynamic bot personas (Apex, Chief of Staff, Code Architect, Researcher, Automator) with Chief of Staff live roster interpolation, token caps, and `PeerApprovalCoordinator` inter-bot gating.
- **Coordination Protocols**: `GroupChatSession` (round-robin multi-bot turns), `DelegateTaskTool` (hierarchical task delegation with `TaskResult` logging), `ConveneMeetingTool` (multi-round panel debates with `ConsensusReport` tracking), `TurnWatchdog` (stall detection), and `RepeatDetector` (loop breaking).
- **Tool Governance & Safety**: 30+ native tools + MCP/dynamic scripts under `@ToolActor` isolation with 3-tier risk classification, auto-approval regex guards, `.apex-bak` rollback stashing, and prompt injection sanitization.
- **Observability & Broadcasting**: Capped ring buffer `TraceBus` (400 events), unified `Tracing.span()` coordinator, Instruments `os_signpost` spans, OSLog structured logging, and port 1337 `ApexGatewayServer` TCP daemon with strict connection lifecycle management.

---

## Feature Inventory
| # | Feature | Description | Milestone | Source |
|---|---------|-------------|-----------|--------|
| F1 | Swift 6.4 Strict Concurrency & Build Matrix | Full build & test passes across `ApexAgentTests`, `ApexAgentIntelligenceTests`, `ApexAgentContainerTests`, `ApexAgentUITests` with complete concurrency safety. | M1 | ORIGINAL_REQUEST §R3 |
| F2 | SwiftData Model Persistence & Migration | Accurate save, restore, and cascade deletion for `BotProfile`, `Conversation`, `Message`, `Routine`, `Skill`, etc. | M1 | ORIGINAL_REQUEST §R3 |
| F3 | Zero Session Broadcasting Leaks & Concurrency Safety | Validating `TraceBus` async streams, actor isolation, and `ApexGatewayServer` socket cleanups. | M1 | ORIGINAL_REQUEST §R3 |
| F4 | Live Bot Roster Execution | Verification of Apex, Chief of Staff, Code Architect, Researcher, and Automator personas, generation, and tool usage. | M2 | ORIGINAL_REQUEST §R1 |
| F5 | Multi-Engine Backend Dispatch | Live engine routing and execution across Native Apple Foundation Models, Local Ollama, and Local MLX. | M2 | ORIGINAL_REQUEST §R1 |
| F6 | Multi-Agent Coordination & Delegation | Live validation of concurrent group chats, `DelegateTaskTool` handoffs, and `ConveneMeetingTool` panel debates. | M2 | ORIGINAL_REQUEST §R1 |
| F7 | Deep Subsystem Integrity & Function | Deep evaluation of `AgentOrchestrator`, `BotManager`, `GroupChatManager`, `ComputerUseAgent`, `VoiceController`, `RoutineManager`, and `TraceBus`. | M3 | ORIGINAL_REQUEST §R2 |
| F8 | Bot Output Quality & Token Efficiency | Verification of response accuracy, coherence, persona adherence, context pruning, and token efficiency. | M3 | ORIGINAL_REQUEST §R2 |
| F9 | Safety Gating, Sandboxing & Resilience | Context window limits, network timeouts, sandbox boundaries (`SecuritySandboxError`), and destructive command confirmation gating (`ApprovalPolicy`). | M3 | ORIGINAL_REQUEST §R2 |
| F10 | Comprehensive E2E Verification & Adversarial Hardening | Tier 1-4 requirement-driven E2E tests, Tier 5 adversarial stress testing, and Forensic Integrity Audit (zero mocks/stubs). | M4 | ORIGINAL_REQUEST §R1-R3 |

---

## Milestones
| # | Name | Scope | Dependencies | Status |
|---|------|-------|-------------|--------|
| M1 | Automated Test Matrix & Concurrency Validation | Execute full test matrix (`xcodebuild test`), verify Swift 6.4 strict concurrency, SwiftData persistence, and zero broadcasting leaks. | none | IN_PROGRESS |
| M2 | Live Multi-Bot & Multi-Engine End-to-End Evaluation | Validate live generation across all 5 bot personas, multi-engine backends (Apple FM, Ollama, MLX), group chat, delegation, and panel debates. | M1 | PLANNED |
| M3 | Deep Subsystem Integrity, Quality & Safety Gating | Deep-dive evaluation of `AgentOrchestrator`, `BotManager`, `ComputerUseAgent`, `VoiceController`, `RoutineManager`, `TraceBus`, token efficiency, and confirmation gating. | M2 | PLANNED |
| M4 | Comprehensive E2E Hardening & Forensic Audit | Requirement-driven E2E tests (Tiers 1-4), adversarial stress tests (Tier 5), Challenger verification, and Forensic Integrity Audit. | M3 | PLANNED |

---

## Interface Contracts

### BotManager ↔ BotSession
- `BotManager.startSession(for bot: BotProfile, in conversation: Conversation) -> BotSession`
- Dynamic instruction assembly injecting working memory and Chief of Staff team roster.

### AgentOrchestrator ↔ Tool Registry
- `AgentOrchestrator.executeTool(name: String, arguments: [String: Any]) async throws -> ToolResult`
- Protected by `@ToolActor`, `ApprovalPolicy.evaluate(tool:arguments:)`, and `SecretRedactor`.

### GroupChatManager ↔ GroupChatSession
- `GroupChatSession.stepTurn() async throws -> GroupChatMessage`
- Enforces `DefaultGroupToolAllowlist`, round-robin speaker turns, and `TurnWatchdog` stall monitoring.

### DelegateTaskTool & ConveneMeetingTool ↔ Multi-Agent Runtime
- `DelegateTaskTool.execute(botId: String, task: String) async throws -> TaskResult`
- `ConveneMeetingTool.execute(participants: [String], topic: String, rounds: Int) async throws -> ConsensusReport`

---

## Code Layout
- `ApexAgent/`: Main application source, views, and view models.
  - `ApexAgentApp.swift`: App lifecycle, SwiftData schema container registration.
  - `AgentOrchestrator.swift`: Main execution loop, tool dispatch, context compaction.
  - `Models/`: Core domain models (`BotManager.swift`, `BotProfile.swift`, `GroupChat.swift`, `Routine.swift`, `TraceBus.swift`, `Computer.swift`, `VoiceController.swift`, etc.).
  - `Tools/`: Native tool implementations (`DelegateTaskTool.swift`, `ConveneMeetingTool.swift`, `FileOperations.swift`, `ShellTool.swift`, etc.).
  - `Security/`: `ApprovalPolicy.swift`, `AgentSecurity.swift`, `SecretRedactor.swift`, `SecuritySandboxError.swift`.
- `Modules/`: Inlined SwiftPM framework modules.
  - `SharedLogging/`: `Logger+Extensions.swift`, `SharedLogger.swift`.
  - `SharedModels/`: Core SwiftData entity definitions and migration schema.
  - `SharedKit/`: Shared utilities, data formatting, and token helpers.
  - `MCPKit/`: Model Context Protocol client/server implementations.
- `ApexAgentTests/`: Unit and integration test suite.
- `ApexAgentIntelligenceTests/`: Vision OCR, multimodal, and intelligence benchmarks.
- `ApexAgentContainerTests/`: Apple virtualization container test harness.
- `ApexAgentUITests/`: XCUITest UI automation suite.
