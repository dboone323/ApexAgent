# Handoff Report: R3 (Containerization & Sandboxctl Enhancements)

## 1. Observation

1. **`ContainerManager.swift` (`ApexAgent/Models/ContainerManager.swift`)**:
   - Lines 13-36: `ContainerManager` manages container state (`.idle`, `.downloadingKernel`, `.pullingImage`, `.starting`, `.running`, `.stopping`, `.errored`).
   - Lines 284-328: Hardcodes single container ID `"apex-sandbox"` and mounts `FileManager.default.currentDirectoryPath` via `Containerization.Mount.share(source: workspace, destination: workspace)` unconditionally.
   - Lines 228-236: Networking unconditionally attempts `VmnetNetwork()`.
   - Lines 405-429: Execution is performed via `exec(_:workingDirectory:)` and `startInteractiveShell(onOutput:onExit:)`.
   - **Observation**: There is currently no `ContainerIsolationLevel` enum or parameter, no disk checkpoint/snapshot methods, and no validation on the workspace mount path.

2. **`sandboxctl` (`Tools/sandboxctl/main.swift`)**:
   - Lines 18-51: `SandboxCtl.main()` executes a hardcoded sequential run: `startContainer()`, `exec("echo APEX_SANDBOX_OK")`, `stopContainer()`.
   - **Observation**: It does not parse command line arguments or support subcommands for isolation levels, snapshots, custom execution, or security verification.

3. **`ApprovalPolicy.swift` (`ApexAgent/Security/ApprovalPolicy.swift`)**:
   - Lines 145-154:
     ```swift
     if isContainerSandboxed {
         let hostDiskDestructive = matchFirst([
             try! NSRegularExpression(pattern: #"\bdiskutil\s+erase|\bdd\s+[^|]*\bof=/dev/(r?disk|nvme)"#, options: [.caseInsensitive]),
             try! NSRegularExpression(pattern: #"\bmkfs\b"#, options: [.caseInsensitive])
         ], in: summary)
         if let hostDiskDestructive {
             return ApprovalVerdict(approve: nil, source: .destructiveGuard, rule: hostDiskDestructive)
         }
         return ApprovalVerdict(approve: "auto-approved in Apple Container sandbox", source: .containerSandbox, rule: nil)
     }
     ```
   - **Observation**: Auto-approves commands inside container while blocking host disk destruction (`diskutil erase`, `mkfs`, `dd of=/dev/disk*`). However, host vs container governance profiles are not parameterized as standalone structures.

4. **`AgentOrchestrator.swift` (`ApexAgent/AgentOrchestrator.swift`)**:
   - Lines 420-472: `verifyPathAllowed` verifies paths against workspace, temp, skills, and user folder toggles (`desktopFolderAllowed`, `documentsFolderAllowed`, `downloadsFolderAllowed`, `musicFolderAllowed`).
   - Lines 485-516: `isCommandOrScriptAllowed` checks string containment for user folders when not in container sandbox.
   - **Observation**: Symlink traversal check does not throw `.symlinkTraversal(path)`, and root `/` or system paths are not explicitly guarded in `isCommandOrScriptAllowed`.

5. **Existing Test Coverage**:
   - `ApexAgentContainerTests/ContainerManagerTests.swift`: Contains only 3 tests verifying default state, configuration updates, and idle failure.
   - `ApexAgentTests/SandboxTests.swift`: Contains 7 tests checking basic path/command permission rejections and ApprovalPolicy verdicts.

---

## 2. Logic Chain

1. **Isolation Levels**: Because different agent tasks require different trade-offs between isolation and system capabilities (e.g. untrusted code execution vs connected development vs ephemeral scratchpad builds), `ContainerIsolationLevel` (`.strict`, `.standard`, `.ephemeralOverlay`) must be introduced to `ContainerManager` to dynamically configure network enablement, mount options (`ro` vs `rw`), and workspace overlays (referencing Observation 1).
2. **Snapshot & Checkpoint Rollback**: Risky or multi-step operations inside containers can corrupt guest filesystem state. Because macOS APFS provides zero-cost copy-on-write cloning via `FileManager.default.copyItem`, `ContainerManager` can implement instant snapshot capture (`createSnapshot`), listing (`listSnapshots`), and restoration (`rollbackToSnapshot`) of container state under `imagestore/snapshots/<containerId>/<snapshotId>` (referencing Observation 1).
3. **Host vs Container Governance**: `ApprovalPolicy` already exhibits differentiated handling for host vs container (Observation 3). Formalizing this into `SecurityGovernanceProfile` (`.hostStrict`, `.hostStandard`, `.containerStrict`, `.containerStandard`) provides clean, testable, and declarative governance rules across tools and CLI harnesses.
4. **Boundary Enforcement & Escape Prevention**: `verifyPathAllowed` and `isCommandOrScriptAllowed` need to prevent path traversal (`..`), system root access (`/`, `/System`, `/Library`, `/etc`), and symlink escapes by resolving canonical paths and throwing `SecuritySandboxError.symlinkTraversal` (referencing Observation 4). Additionally, `ContainerManager` must guard host workspace mount paths against mounting root `/` or unauthorized home directories into the micro-VM (referencing Observation 1).
5. **CLI & Test Coverage**: Upgrading `sandboxctl` with CLI argument parsing allows manual and automated verification of container isolation, snapshots, and security boundaries. Expanding `ApexAgentContainerTests` and `ApexAgentTests` with real functional tests provides 100% verification without mocks or stubs (referencing Observations 2 & 5).

---

## 3. Caveats

- Apple Virtualization framework micro-VM boot requires runtime entitlement `com.apple.security.virtualization`, which is carried by the `sandboxctl` binary and the main app bundle (`ApexAgent.app`), but cannot be attached to standard `xctest` runner processes. Unit tests in `ApexAgentContainerTests` therefore test configuration logic, disk snapshotting, and error branches directly using real filesystem operations, while end-to-end VM boot is verified via `sandboxctl`.
- No other caveats.

---

## 4. Conclusion

The design for R3 is fully mapped, scoped, and ready for implementation. It requires:
1. Defining `ContainerIsolationLevel` and updating `ContainerManager` / `ContainerManagerProtocol` to support dynamic isolation configurations.
2. Implementing APFS-backed snapshot creation, listing, rollback, and deletion in `ContainerManager`.
3. Creating `SecurityGovernanceProfile` and connecting governance evaluations with `ApprovalPolicy`.
4. Hardening `verifyPathAllowed`, `isCommandOrScriptAllowed`, and container workspace mount validation with strict boundary and symlink escape checks.
5. Enhancing `Tools/sandboxctl` with subcommands for execution, status, snapshots, and security checks.
6. Adding real functional test suites to `ApexAgentContainerTests` and `ApexAgentTests`.

---

## 5. Verification Method

To independently verify these findings:
1. Inspect `ApexAgent/Models/ContainerManager.swift` lines 216-335 to confirm container lifecycle and mount behavior.
2. Inspect `Tools/sandboxctl/main.swift` lines 1-52 to confirm CLI harness implementation.
3. Inspect `ApexAgent/Security/ApprovalPolicy.swift` lines 140-190 to confirm container vs host verdict logic.
4. Inspect `ApexAgent/AgentOrchestrator.swift` lines 420-516 to confirm path and command validation.
5. Run test suite:
   ```bash
   swift test --filter ContainerManagerTests
   swift test --filter SandboxTests
   ```
