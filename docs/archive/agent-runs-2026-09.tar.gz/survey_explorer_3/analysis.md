# Architectural Analysis: R3 (Containerization & Sandboxctl Enhancements)

## Executive Summary
This report presents an in-depth investigation and architectural design for **R3: Containerization & Sandboxctl Enhancements** in ApexAgent (`dboone323/ApexAgent`). The investigation covers:
1. **Container Execution Isolation Levels** in `ContainerManager` and `sandboxctl`.
2. **Container Checkpointing and Disk Snapshot Rollbacks** via APFS copy-on-write cloning.
3. **Host vs Container Security Governance Profiles** (`SecurityGovernanceProfile`).
4. **Strict Host Filesystem Boundary Enforcement** (`~/Desktop`, `~/Documents`, `~/Downloads`, `~/Music`, root `/`, symlink traversals) and **Sandbox Escape Prevention**.
5. **CLI Harness Enhancements** for `Tools/sandboxctl`.
6. **Real-World Functional Test Matrix** for `ApexAgentContainerTests` and `ApexAgentTests` under Swift 6.4 strict concurrency.

---

## 1. Subsystem Investigation & Current Architecture

### 1.1 `ContainerManager.swift` (`ApexAgent/Models/ContainerManager.swift`)
- **Role**: Main-actor observable class wrapping Apple's `Containerization` library (pinned to release tag `0.38.0`).
- **Current State**:
  - `startContainer()` creates a hardcoded container ID `apex-sandbox`.
  - Unconditionally mounts the current working directory:
    ```swift
    let czMount = Containerization.Mount.share(
        source: workspace,
        destination: workspace
    )
    config.mounts.append(czMount)
    ```
  - Unconditionally attempts `VmnetNetwork()` networking on macOS 26+.
  - Unconditionally starts `/bin/sleep infinity` as PID 1 init process.
  - Interactive process execution: `startInteractiveShell(onOutput:onExit:)` via `PipeReaderStream` and `LinuxProcessConfiguration`.
  - Batch command execution: `exec(command:workingDirectory:)` via `LinuxProcessConfiguration`.
- **Gaps**:
  - Lacks isolation level abstractions (e.g. strict without networking vs standard with network vs ephemeral overlay).
  - Lacks checkpointing / snapshotting APIs.
  - Lacks mount validation (no check preventing mounting `/` or user sensitive roots as the workspace).
  - `ContainerManagerProtocol` in `PTYSession.swift` is missing isolation level signatures and snapshot methods.

### 1.2 `Tools/sandboxctl` (`Tools/sandboxctl/main.swift`)
- **Role**: Entitled verification CLI harness for native Apple micro-VM virtualization. Entitled with `com.apple.security.virtualization` via `ApexAgent.entitlements`.
- **Current State**:
  - A 52-line static verification script that boots the container, runs `echo APEX_SANDBOX_OK`, checks exit code 0, and stops.
- **Gaps**:
  - No CLI subcommands or flag parsing (`--isolation`, `run`, `snapshot`, `status`, `verify-security`).
  - Cannot test snapshots, rollback, custom workloads, or isolation levels.

### 1.3 `ApprovalPolicy.swift` (`ApexAgent/Security/ApprovalPolicy.swift`)
- **Role**: Pure-logic policy engine determining auto-approval vs confirmation gating for tool execution.
- **Current State**:
  - Fast-path for container execution:
    ```swift
    if isContainerSandboxed {
        let hostDiskDestructive = matchFirst([
            try! NSRegularExpression(pattern: #"\bdiskutil\s+erase|\bdd\s+[^|]*\bof=/dev/(r?disk|nvme)"#, options: [.caseInsensitive]),
            try! NSRegularExpression(pattern: #"\bmkfs\b"#, options: [.caseInsensitive])
        ], in: summary)
        if let hostDiskDestructive {
            return ApprovalVerdict(approve: nil, source: .destructiveGuard, rule: hostDiskDestructive)
        }
        return ApprovalVerdict(approve: "auto-approved in Apple Container sandbox", source: .containerSandbox, rule: nil)
    }
    ```
  - Host execution: checks `ApprovalRule.destructive` and `ApprovalRule.sensitive`.
- **Gaps**:
  - Governance policies are hardcoded rather than parameterized by formal `SecurityGovernanceProfile`.
  - Does not distinguish between strict container isolation (e.g. no network, read-only mounts) and standard container isolation.

### 1.4 `AgentOrchestrator.swift` & Path Boundary Enforcement
- **Role**: Coordinates workspace management, permissions, and sandbox path validation.
- **Current State**:
  - `verifyPathAllowed(_ path: String)` checks:
    - User folder toggles (`desktopFolderAllowed`, `documentsFolderAllowed`, `downloadsFolderAllowed`, `musicFolderAllowed`).
    - Allowed roots: `currentWorkspacePath`, `NSTemporaryDirectory()`, `~/.apex/skills`.
    - Security-scoped bookmarks: `accessSandboxBookmark(for:)`.
  - `isCommandOrScriptAllowed(_ input: String, isContainerSandboxed: Bool)`:
    - If `isContainerSandboxed == true` -> returns `true`.
    - On host -> checks if command string contains `desktopPath`, `documentsPath`, etc.
- **Gaps**:
  - `verifyPathAllowed` does not explicitly throw `.symlinkTraversal` when a symlink resolves outside the allowed root (it falls through to `.pathViolation`).
  - `isCommandOrScriptAllowed` relies solely on substring matching (`input.contains(desktopPath)`), which can be bypassed via tilde expansion (`~/Desktop`), relative paths (`../Desktop`), or variable substitutions.
  - Root directory `/` and system roots (`/System`, `/Library`, `/etc`, `/var`, `/usr`, `/bin`, `/sbin`) are not explicitly guarded in command validation.

### 1.5 `FileRollback.swift` (`ApexAgent/Security/FileRollback.swift`)
- **Role**: Snapshotting individual files prior to destructive write/delete operations on the host filesystem.
- **Current State**:
  - Creates `<path>.apex-bak` sidecar files before modifications and restores them upon rollback.
- **Relationship to R3**:
  - Operates at the single-file level on the host; container disk snapshots must operate at the container image / rootfs level.

---

## 2. Technical Design & Proposed Extensions

### 2.1 Container Execution Isolation Levels
We propose formalizing `ContainerIsolationLevel` as a first-class enum in `ApexAgentCore`:

```swift
public enum ContainerIsolationLevel: String, Sendable, Codable, CaseIterable {
    /// Strict isolation: no network interface, read-only workspace mount, ephemeral rootfs, highest escape prevention.
    case strict = "strict"
    
    /// Standard isolation: virtual network (vmnet) enabled, read-write workspace mount, ephemeral rootfs.
    case standard = "standard"
    
    /// Ephemeral overlay isolation: virtual network enabled, workspace mounted via copy-on-write scratch directory
    /// so in-guest edits do not mutate host files until explicitly committed.
    case ephemeralOverlay = "overlay"
}
```

#### `ContainerManager` Enhancements:
1. **Property**:
   ```swift
   public var isolationLevel: ContainerIsolationLevel {
       get {
           let raw = UserDefaults.standard.string(forKey: "apex.containerIsolationLevel") ?? "standard"
           return ContainerIsolationLevel(rawValue: raw) ?? .standard
       }
       set {
           UserDefaults.standard.set(newValue.rawValue, forKey: "apex.containerIsolationLevel")
       }
   }
   ```
2. **`startContainer(isolationLevel:)` Signature**:
   ```swift
   public func startContainer(isolationLevel: ContainerIsolationLevel? = nil) async throws {
       let level = isolationLevel ?? self.isolationLevel
       // Configure networking:
       let enableNetwork = (level != .strict)
       var network: Network? = nil
       if enableNetwork, #available(macOS 26, *) {
           network = try? VmnetNetwork()
       }
       
       // Configure workspace mounts:
       let workspace = FileManager.default.currentDirectoryPath
       // Enforce host boundary guard before mounting:
       try verifyWorkspaceMountSafety(workspace)
       
       let mountOptions: [String]
       switch level {
       case .strict:
           mountOptions = ["ro"]
       case .standard:
           mountOptions = ["rw"]
       case .ephemeralOverlay:
           // Create ephemeral staging scratch workspace
           mountOptions = ["rw"]
       }
       ...
   }
   ```

---

### 2.2 Container Checkpointing & Disk Snapshot Rollbacks
To enable checkpoint rollbacks for container workloads:

#### Data Structure:
```swift
public struct ContainerSnapshot: Sendable, Codable, Identifiable, Equatable {
    public let id: String
    public let name: String
    public let containerId: String
    public let imageRef: String
    public let createdAt: Date
    public let sizeInBytes: Int64
    public let isolationLevel: ContainerIsolationLevel
    public let description: String?
}
```

#### Snapshot Mechanism via APFS Clonefile:
- **Location**: `appRoot.appendingPathComponent("imagestore/snapshots/\(containerId)/\(snapshotId)")`.
- **Creation**:
  1. Ensure container state directory (`imagestore/containers/\(containerId)`) exists.
  2. Perform fast copy-on-write directory clone:
     ```swift
     try FileManager.default.copyItem(at: containerPath, to: snapshotPath)
     ```
  3. Write `snapshot.json` metadata sidecar.
- **Rollback**:
  1. If container is running, call `stopContainer()`.
  2. Remove current `imagestore/containers/\(containerId)`.
  3. Clone `snapshotPath` back to `imagestore/containers/\(containerId)`.
  4. Reset container manager state.
- **APIs on `ContainerManager`**:
  ```swift
  public func createSnapshot(name: String, description: String? = nil) async throws -> ContainerSnapshot
  public func listSnapshots() async throws -> [ContainerSnapshot]
  public func rollbackToSnapshot(nameOrId: String) async throws
  public func deleteSnapshot(nameOrId: String) async throws
  ```

---

### 2.3 Host vs Container Security Governance Profiles
We introduce `SecurityGovernanceProfile` to unify security evaluation:

```swift
public enum ExecutionScope: String, Sendable, Codable, CaseIterable {
    case host = "host"
    case container = "container"
}

public struct SecurityGovernanceProfile: Sendable, Codable, Equatable {
    public let id: String
    public let name: String
    public let scope: ExecutionScope
    public let isolationLevel: ContainerIsolationLevel
    public let allowNetwork: Bool
    public let allowHostFilesystemMount: Bool
    public let autoApprovePackageInstall: Bool
    public let blockDestructiveHostCommands: Bool
    public let blockSensitiveFileAccess: Bool
    public let restrictedHostPaths: [String]
    
    public static let hostStrict = SecurityGovernanceProfile(
        id: "host-strict",
        name: "Host Strict Security",
        scope: .host,
        isolationLevel: .strict,
        allowNetwork: false,
        allowHostFilesystemMount: false,
        autoApprovePackageInstall: false,
        blockDestructiveHostCommands: true,
        blockSensitiveFileAccess: true,
        restrictedHostPaths: ["~/Desktop", "~/Documents", "~/Downloads", "~/Music", "/", "/System", "/Library", "/etc", "/var", "~/.ssh", "~/.aws"]
    )
    
    public static let hostStandard = SecurityGovernanceProfile(
        id: "host-standard",
        name: "Host Standard Security",
        scope: .host,
        isolationLevel: .standard,
        allowNetwork: true,
        allowHostFilesystemMount: true,
        autoApprovePackageInstall: false,
        blockDestructiveHostCommands: true,
        blockSensitiveFileAccess: true,
        restrictedHostPaths: ["~/Desktop", "~/Documents", "~/Downloads", "~/Music", "/", "/System", "/Library", "/etc", "/var", "~/.ssh", "~/.aws"]
    )
    
    public static let containerStandard = SecurityGovernanceProfile(
        id: "container-standard",
        name: "Container Standard Sandbox",
        scope: .container,
        isolationLevel: .standard,
        allowNetwork: true,
        allowHostFilesystemMount: true,
        autoApprovePackageInstall: true,
        blockDestructiveHostCommands: true,
        blockSensitiveFileAccess: false,
        restrictedHostPaths: ["/", "/System", "/Library", "/etc", "/var"]
    )
    
    public static let containerStrict = SecurityGovernanceProfile(
        id: "container-strict",
        name: "Container Strict Sandbox",
        scope: .container,
        isolationLevel: .strict,
        allowNetwork: false,
        allowHostFilesystemMount: false,
        autoApprovePackageInstall: true,
        blockDestructiveHostCommands: true,
        blockSensitiveFileAccess: true,
        restrictedHostPaths: ["/", "/System", "/Library", "/etc", "/var", "~/.ssh", "~/.aws"]
    )
}
```

---

### 2.4 Strict Host Filesystem Boundary Enforcement & Sandbox Escape Prevention
To prevent sandbox escapes and unauthorized host file access:

1. **System Root & Path Traversal Guards**:
   - Explicitly block attempts to target `/`, `/System`, `/Library`, `/usr`, `/bin`, `/sbin`, `/etc`, `/var`, `/private`.
   - Canonicalize all input paths before verification:
     ```swift
     let standardized = URL(fileURLWithPath: expanded).standardized.resolvingSymlinksInPath().path
     ```
   - If symlink resolves outside allowed roots (`workspace`, `temporaryDirectory`, `.apex/skills`), throw `SecuritySandboxError.symlinkTraversal(path)`.
2. **User Directory Boundary Enforcement**:
   - Check user directory permissions for `~/Desktop`, `~/Documents`, `~/Downloads`, `~/Music`.
   - Detect both tilde (`~/Desktop`) and absolute (`/Users/.../Desktop`) and relative (`../../Desktop`) spellings in `isCommandOrScriptAllowed`.
3. **Container Workspace Mount Guard**:
   - `ContainerManager` must verify that the host workspace path being mounted is an allowed path under `AgentOrchestrator.verifyPathAllowed` and NOT `/` or `~`.

---

### 2.5 `Tools/sandboxctl` CLI Tool Enhancements
`sandboxctl` should be upgraded with command-line argument dispatching:

```
Usage: sandboxctl <subcommand> [options]

Subcommands:
  (no args)             Run default verification test (boot VM + echo APEX_SANDBOX_OK)
  run <cmd>             Execute command in container (options: --isolation <strict|standard|overlay>, --image <ref>)
  status                Display container state, resources, isolation level, and snapshots
  snapshot create <name> Create a container checkpoint snapshot
  snapshot list         List all existing container snapshots
  snapshot rollback <name> Restore container to specified snapshot
  snapshot delete <name> Delete specified snapshot
  verify-security       Execute security boundary enforcement & sandbox escape checks
```

---

## 3. Comprehensive Test Strategy & Matrix

All tests adhere strictly to the **Testing Principle** (100% real functional code, zero mocks or stubs).

### Test Matrix Breakdown:

| Test Suite | File | Coverage Areas |
|---|---|---|
| `ApexAgentContainerTests` | `ContainerManagerTests.swift` | • `ContainerIsolationLevel` configurations & transitions<br>• Snapshot creation, listing, rollback & deletion on disk<br>• Error handling on missing snapshots or invalid state |
| `ApexAgentTests` | `SandboxTests.swift` | • Strict host boundary enforcement (Desktop, Documents, Downloads, Music)<br>• System root guards (`/`, `/System`, `/Library`, `/etc`)<br>• Symlink traversal detection (`SecuritySandboxError.symlinkTraversal`)<br>• Host vs Container `ApprovalPolicy` evaluations |
| `ApexAgentTests` | `SecurityGovernanceTests.swift` | • `SecurityGovernanceProfile` evaluation for Host vs Container<br>• Strict vs Standard governance rules<br>• Escape prevention validations |
| `ApexAgentTests` | `SandboxCtlCLITests.swift` | • CLI argument parsing and subcommand routing for `sandboxctl` |

---

## 4. Implementation Readiness & Risk Assessment

- **Concurrency & Memory Safety**: All additions strictly follow Swift 6.4 actor isolation (`@MainActor` for `ContainerManager`, Sendable structs for `ContainerSnapshot`, `ContainerIsolationLevel`, and `SecurityGovernanceProfile`).
- **Disk Efficiency**: Snapshotting leverages APFS `clonefile` copy-on-write, ensuring instant snapshot creation with 0 additional disk allocation until modified.
- **Backward Compatibility**: `sandboxctl` retains default zero-argument behavior outputting `APEX_SANDBOX_OK` with exit 0.
