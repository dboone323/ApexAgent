## 2026-08-27T20:49:17Z
You are worker_m4 assigned to Milestone M4 (Dynamic Script & MCP Server Discovery UI).

Working directory: /Users/danielstevens/Developer/ApexAgent/.agents/worker_m4
Read:
- /Users/danielstevens/Developer/ApexAgent/.agents/ORIGINAL_REQUEST.md
- /Users/danielstevens/Developer/ApexAgent/PROJECT.md
- /Users/danielstevens/Developer/ApexAgent/TEST_INFRA.md
- /Users/danielstevens/Developer/ApexAgent/TEST_READY.md
- /Users/danielstevens/Developer/ApexAgent/.agents/survey_explorer_1/analysis.md

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Testing Principle: All tests must be implemented using REAL functional code that performs real validations. Never use mocks, placeholders, stubs, or dummy/fake tests.

Exclusive File Ownership:
- ApexAgent/UI/DynamicToolboxManagerSection.swift (or new views under ApexAgent/UI/MCPServerDashboardView.swift / DynamicScriptEditorView.swift)
- ApexAgent/UI/SettingsView.swift (wiring MCP Server Dashboard & Dynamic Script Editor)
- ApexAgent/Models/MCPClient.swift (if any dashboard-facing helpers are needed)

Tasks:
1. In `ApexAgent/UI/DynamicToolboxManagerSection.swift` (and/or dedicated views):
   - Implement `MCPServerDashboardView`:
     - Display active and configured MCP servers with live status indicator badges (`running` green, `stopped` gray, `circuit_open` red/orange).
     - Display transport channel info (stdio subprocess path / args vs SSE/HTTP URL).
     - Display live roundtrip latency measurement (in ms) with a "Ping" button that invokes `measureLatency()`.
     - Interactive registered tools catalog: expandable list showing tool names, descriptions, input schemas, and execution state.
     - Controls to Reset Circuit breaker, Restart server, Add new MCP server, and Delete server.
   - Implement `DynamicScriptEditorView`:
     - List all custom `.sh` script tools and `.json` manifests under `~/.apex/skills/`.
     - Allow selecting a script, viewing/editing the shell script source code and JSON schema.
     - Provide a "Test Run" button with custom argument inputs, executing the script via `Process` and displaying real stdout, stderr, exit code, and execution duration in an interactive console pane.
     - Provide a "Save & Reload" button that persists changes (`chmod 0755`), syncs JSON manifest, and hot-reloads `DynamicToolbox.shared.loadTools()` and `SkillManager.shared.syncFromDisk()`.
2. In `ApexAgent/UI/SettingsView.swift`:
   - Wire the MCP Server Dashboard and Dynamic Script Editor tabs/sections so users can navigate and use both seamlessly.
3. Build and verify:
   - Run `swift build` and `swift test --filter MCPServerDashboardTests` (and full `swift test`). Ensure zero warnings and 100% tests pass.

Write your report to /Users/danielstevens/Developer/ApexAgent/.agents/worker_m4/handoff.md and notify caller.
