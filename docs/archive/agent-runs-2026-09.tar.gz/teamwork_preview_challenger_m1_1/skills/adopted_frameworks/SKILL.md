---
name: adopted-frameworks
description: Reference and search local high-quality development guides, coding patterns, architecture plans, and library documentations (e.g., ApexAgent/shared-kit sync guidelines, Next.js code structures).
---
# Adopted Frameworks Skill

This skill allows the agent to quickly find and reference local documentation for adopted frameworks, external APIs, style guides, and project-specific architecture diagrams.

## How to use
When the user mentions a library, architecture pattern, or tool matching this skill, query the local database/files using the `search_docs.py` tool script or grep tools.

## Directory Structure
- `references/`: Place markdown files (`.md`) containing documentation.
- `scripts/search_docs.py`: Search script to find terms or regexes in the referenced files.
