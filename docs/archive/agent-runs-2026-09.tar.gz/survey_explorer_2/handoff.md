# Handoff Report — R2 Autonomous Multi-Agent Playbook Templates & Presets

## 1. Observation
- **Existing Models**:
  - `ApexAgent/Models/TeamPlaybook.swift` (lines 3–212) defines `PlaybookBot` and `TeamPlaybook`, handling JSON encoding/decoding and Markdown frontmatter serialization. It strictly models bot persona rosters (`name`, `title`, `description`, `avatarName`, `isChiefOfStaff`, `modelProvider`, `ollamaModel`, `memory`), with no concept of workflow stages, dispatch modes, or approval gates.
  - `ApexAgent/Models/BotManager.swift` (lines 26–442) manages `BotProfile` records and `BotSession` instances. It seeds 5 standard bots on empty stores: Apex, Chief of Staff (`isChiefOfStaff = true`), Code Architect, Researcher, Automator (lines 309–343). It coordinates peer approvals via `PeerApprovalCoordinator` (`peerDeliveryDecision`, `resolvePeerRequest`, lines 79–124) and imports/exports `TeamPlaybook` (lines 378–441).
  - `ApexAgent/Models/GroupChat.swift` (lines 59–483) implements `GroupChatSession` and `GroupChatManager`, executing sequential round-robin turns across participants (`generationOrder`, `currentTurnIndex`, lines 158–248) and enforcing tool allowlists (`groupToolPermission`, `executeGroupTool`, lines 338–374).
  - `ApexAgent/Models/ChiefOfStaff.swift` (lines 20–112) composes dynamic system prompts with bounded roster interpolation (`rosterMaxBots = 40`, `nameMax = 80`, `roleMax = 120`, `aboutMax = 200`).
  - `ApexAgent/Models/PeerApproval.swift` (lines 44–141) implements thread-safe peer approval lifecycle (`requestApproval`, `resolve`, `hasGrant`, `addGrant`, `expireStale`).
  - `ApexAgent/Tools/AskBotTool.swift` (lines 9–91) delegates tasks via `BotManager.peerDeliveryDecision` and executes in the target bot's session asynchronously via `sendMessageAsync`.
- **Existing Test Suites**:
  - `ApexAgentTests/MultiBotParityTests.swift` (lines 179–389) tests `TeamPlaybook` JSON/Markdown serialization and `BotManager` import/export.
  - `ApexAgentTests/MultiBotParityP3Tests.swift` (lines 112–169) tests `GroupChatManager` initialization, concurrent group chats, selection, and cancellation.
  - `ApexAgentTests/DaemonAndPeerGateTests.swift` (lines 70–121) tests `PeerDeliveryGateTests` (unapproved peer message blocking, attention flags, remembered grants).
  - `ApexAgentTests/LiveBotCommunicationTests.swift` (lines 15–90) tests live bot hand-offs against on-device models.

## 2. Logic Chain
1. **Requirement Analysis**: R2 requires built-in collaboration playbook presets (**Full PR Review Loop**, **Issue-to-Patch Pipeline**, **Weekly Standup & Retrospective**), automated multi-bot participant assignment (Chief of Staff, Code Architect, Researcher, Automator, Apex), sequential / parallel turn dispatching, and live tracking of peer delegations and approval cards across stages.
2. **Architectural Gap**: Current playbooks only represent bot roster profiles (`TeamPlaybook`), not multi-stage workflow pipelines. Current group chats only support single-round sequential turns (`GroupChatSession`), not mixed sequential/parallel stage execution or stage approval gating.
3. **Data Model Extension**: We need `CollaborationPlaybook` and `PlaybookStageDefinition` models supporting `PlaybookDispatchMode` (`.sequential`, `.parallel`), `PlaybookRoleRequirement`, `PlaybookPresetKind`, and `requiresApprovalGate`.
4. **Execution Engine**: We need `PlaybookRunner` to:
   - Auto-assign participants using heuristic role matching via `PlaybookParticipantAssigner`.
   - Dispatch stages sequentially or in parallel using Swift structured concurrency (`withThrowingTaskGroup`).
   - Pause at approval checkpoints (`PlaybookApprovalCard`) and resume upon user approval.
   - Record and broadcast live delegation events (`PlaybookDelegationEvent`) to `TraceBus.shared`.
5. **Testing Strategy**: Real functional tests in `ApexAgentTests/PlaybookCollaborationTests.swift` validating preset structure, auto-assignment heuristics, sequential vs parallel dispatching, approval gating transitions, delegation event tracking, and end-to-end execution without mocks or stubs.

## 3. Caveats
- `TeamPlaybook` import/export in `BotManager` and `BotSidebarViews.swift` must remain fully backward-compatible with existing JSON and Markdown files.
- Real LLM turn execution in tests should support deterministic execution when running in non-live CI environments while supporting live engine generation when `APEX_LIVE_BOTS=1`.

## 4. Conclusion
The ApexAgent codebase possesses robust building blocks (`BotManager`, `BotSession`, `GroupChatManager`, `ChiefOfStaff`, `PeerApprovalCoordinator`, `TraceBus`), making it well-positioned for R2. The implementation of `CollaborationPlaybook`, `PlaybookRunner`, and the three built-in presets will cleanly fulfill all R2 requirements with strict Swift 6.4 concurrency safety and 100% real functional testing.

## 5. Verification Method
- Code inspection of `ApexAgent/Models/CollaborationPlaybook.swift`, `ApexAgent/Models/PlaybookRunner.swift`, and `ApexAgentTests/PlaybookCollaborationTests.swift`.
- Run tests via shell:
  ```bash
  swift test --filter PlaybookCollaborationTests
  swift test --filter TeamPlaybookTests
  swift test --filter BotManagerPlaybookTests
  swift test --filter PeerDeliveryGateTests
  swift test
  ```
- Build check:
  ```bash
  swift build
  ```
