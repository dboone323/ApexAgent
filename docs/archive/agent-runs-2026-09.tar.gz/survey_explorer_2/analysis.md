# R2 Codebase Survey & Deep Analysis: Autonomous Multi-Agent Playbook Templates & Presets

## Executive Summary
This survey provides a comprehensive architectural and codebase analysis for implementing **R2: Autonomous Multi-Agent Playbook Templates & Presets in BotManager / Playbook**. 

The goal of R2 is to extend ApexAgent from simple isolated bot chats and round-robin group chats into a structured, autonomous multi-agent orchestration engine featuring:
1. **Built-in Collaboration Playbook Presets**: Production-grade workflow templates for **Full PR Review Loop**, **Issue-to-Patch Pipeline**, and **Weekly Standup & Retrospective**.
2. **Automated Multi-Bot Participant Assignment**: Intelligent role-to-bot mapping across the standard roster (Chief of Staff, Code Architect, Researcher, Automator, Apex).
3. **Sequential & Parallel Turn Dispatching**: Mixed-mode stage execution supporting both pipeline sequences and concurrent multi-agent fan-out/fan-in processing.
4. **Live Tracking of Peer Delegations & Approval Cards**: Real-time stage lifecycle status, stage-level human-in-the-loop approval cards, peer delegation graphs, and `TraceBus` event streaming.

---

## 1. Codebase Architecture & Current Component Survey

### 1.1 TeamPlaybook.swift (`PlaybookBot`, `TeamPlaybook`)
- **Current Role**: Defines the data model for portable team rosters.
- **Key Types**:
  - `PlaybookBot`: Represents a bot persona (`name`, `title`, `description`, `avatarName`, `isChiefOfStaff`, `modelProvider`, `ollamaModel`, `memory`).
  - `TeamPlaybook`: Encapsulates a team definition with `bots: [PlaybookBot]`, JSON serialization (`encode()`, `decode(from:)`), and Markdown YAML frontmatter parser/generator (`decodeFromMarkdown()`, `toMarkdown()`).
- **Limitation**: Currently models only *team personas/rosters*, without any workflow stages, execution pipelines, dispatch modes, or stage-level approval gates.

### 1.2 BotManager.swift
- **Current Role**: Central `@Observable @MainActor` coordinator for `BotProfile` records (SwiftData persisted) and active `BotSession` instances.
- **Key Capabilities**:
  - Bot lifecycle CRUD (`createBot`, `duplicateBot`, `hideBot`, `deleteBot`, `editBot`, `updateBotMemory`).
  - Default team seeding on first launch: Apex (General Assistant), Chief of Staff (`isChiefOfStaff = true`), Code Architect (Senior Engineer), Researcher (Deep Research Specialist), Automator (macOS System Automator).
  - Session lookup and switching (`session(for:)`, `openConversation`, `setActiveBot`).
  - Peer approval gating: Owns `peerApprovals: PeerApprovalCoordinator`, `peerDeliveryDecision(from:to:message:)`, and `resolvePeerRequest(requestId:allow:remember:)`.
  - Attention tracking: `botsNeedingAttention` based on `needsAttention` or `unreadActivity`.
  - Playbook import/export: `exportPlaybook(name:description:bots:)`, `importPlaybook(_:)`, `importPlaybookFromURL(_:)`.
- **Limitation**: Has no registry or runner for multi-stage collaboration playbooks.

### 1.3 GroupChat.swift (`GroupChatSession`, `GroupChatManager`)
- **Current Role**: Ephemeral multi-bot collaborative chat sessions.
- **Key Capabilities**:
  - `GroupChatSession`: Maintains shared `messages: [ChatMessage]`, participant list `[BotProfile]`, `generationOrder: [UUID]`, `currentTurnIndex: Int`.
  - Execution model: Pure round-robin sequential turn execution (`start()`, `beginNextTurn()`, `runParticipantTurn()`, `advanceTurn()`).
  - Tool execution governance: `groupToolPermission(tool:)` enforcing safe allowlist and human confirmation for risky tools.
  - `GroupChatManager`: Manages concurrent `GroupChatSession` instances (`startGroup`, `selectGroup`, `closeGroup`, `cancelAllGroups`).
- **Limitation**: Only supports sequential round-robin chatting. No multi-stage pipeline, no parallel turn fan-out, and no structured stage input/output synthesis.

### 1.4 ChiefOfStaff.swift
- **Current Role**: Dynamic system prompt composer for Chief of Staff bots.
- **Key Capabilities**:
  - Interpolates live team members into system prompt on every turn with strict bounds (`rosterMaxBots = 40`, `nameMax = 80`, `roleMax = 120`, `aboutMax = 200`).
  - Formats role guidance for delegating via `ask_bot`, assembling teams, and synthesizing outcomes.

### 1.5 BotSession.swift & BotMessageSender.swift
- **Current Role**: Scoped conversation session for an individual bot.
- **Key Capabilities**:
  - Maintains `messages`, `toolEvents`, `isGenerating`, `needsAttention`, `unreadActivity`, `activePlan`.
  - Asynchronous message dispatching: `sendMessageAsync(_:attachments:) async -> String?` with checked continuation bridging streaming completion.
  - Dynamic instructions assembling base persona + durable memory + (if Chief of Staff) live team roster.

### 1.6 Peer Approval & Delegation Tools
- **`PeerApprovalCoordinator` (`PeerApproval.swift`)**:
  - Manages thread-safe pending peer requests (`PendingPeerApproval`) and remembered grants (`grants: Set<String>`).
  - Methods: `requestApproval`, `resolve`, `hasGrant`, `addGrant`, `revokeGrant`, `expireStale`.
- **`AskBotTool` (`AskBotTool.swift`)**:
  - Inter-bot delegation tool calling `BotManager.peerDeliveryDecision`.
  - When allowed, executes in target bot's `BotSession` asynchronously. When blocked, creates pending approval card.
- **`DelegateTaskTool` (`DelegateTaskTool.swift`)**:
  - Supervisor-to-subagent delegation via `AgentRegistry` with depth limit protection (max depth 2) and `TaskResult` handoff logging.
- **`ConveneMeetingTool` (`ConveneMeetingTool.swift`)**:
  - Panel meeting debate between subagents with 2 rounds of discussion and `ConsensusReport` synthesis.

---

## 2. Playbook Definition, Storage, Scheduling & Execution: Current vs. Target

| Dimension | Current Implementation | Target R2 Architecture |
|---|---|---|
| **Definition Model** | `TeamPlaybook`: List of `PlaybookBot` profiles only. | `CollaborationPlaybook` / `PlaybookTemplate`: Rich definition including metadata, required roles, and sequential/parallel `PlaybookStageDefinition` steps. |
| **Preset Library** | None built-in (only export/import of current bots). | Built-in presets: **Full PR Review Loop**, **Issue-to-Patch Pipeline**, **Weekly Standup & Retrospective**. |
| **Participant Assignment** | Manual bot creation / manual group selection. | `PlaybookParticipantAssigner`: Automatic heuristic role matching (`chiefOfStaff`, `codeArchitect`, `researcher`, `automator`, `general`) with auto-fallback. |
| **Execution Engine** | `GroupChatSession` (round-robin talk) or `StateGraph` (generic graph). | `PlaybookRunner`: Full stage pipeline runner executing assigned bot sessions sequentially or in parallel, aggregating outputs, and resolving templates. |
| **Turn Dispatching** | Strictly sequential single-turn execution. | Mixed-mode: `.sequential` (serial hand-offs) and `.parallel` (`withTaskGroup` concurrent multi-bot execution). |
| **Approval Gating** | Tool confirmation (`ConfirmationRequest`) & bot pair grants (`PeerApprovalCoordinator`). | Stage-level approval cards (`PlaybookApprovalCard`) pausing execution at critical milestones before irreversible actions. |
| **Live Tracking** | `TraceBus` general events, `AgentTraceLog`. | Structured `PlaybookExecutionStatus`, `PlaybookStageResult`, and `PlaybookDelegationEvent` tracking. |

---

## 3. Turn Dispatching, Peer Delegation, Approval Gating, and Status Events

### 3.1 Sequential vs Parallel Turn Dispatching
- **Sequential Dispatching**:
  - Used when stage output feeds directly as context into the next bot's prompt.
  - Pattern: Execute Bot A -> await completion -> inject output into Bot B's prompt template -> execute Bot B.
- **Parallel Dispatching**:
  - Used when multiple specialists perform independent analysis simultaneously (e.g. Code Architect reviewing code while Researcher checks security/docs; or all bots preparing standup updates).
  - Pattern: Use Swift structured concurrency `withThrowingTaskGroup` to run `session.sendMessageAsync` across multiple participant sessions in parallel, gather all responses, and join them into a multi-part stage output.

### 3.2 Live Tracking of Peer Delegations
- When a bot within a stage delegates to another bot (via `ask_bot`), or when the runner coordinates a hand-off:
  - Record a `PlaybookDelegationEvent` containing:
    - `id: UUID`
    - `playbookId: UUID`
    - `stageId: String`
    - `fromBotId: UUID`
    - `fromBotName: String`
    - `toBotId: UUID`
    - `toBotName: String`
    - `action: String`
    - `message: String`
    - `status: PlaybookDelegationStatus` (`.pendingApproval`, `.inProgress`, `.completed`, `.failed`)
    - `resultSummary: String?`
    - `timestamp: Date`
  - Emit a `TraceEvent` to `TraceBus.shared` with category `"playbook"` and operation `"delegation"`.

### 3.3 Stage Approval Cards & Gating
- Stages can declare `requiresApprovalGate: Bool` (e.g., Stage 3 in Issue-to-Patch Pipeline before modifying repository files; or Stage 3 in PR Review Loop before running heavy test builds).
- When a gated stage is reached:
  1. The runner halts execution and transitions status to `.waitingForApproval(card: PlaybookApprovalCard)`.
  2. `PlaybookApprovalCard` captures: `id`, `stageId`, `stageName`, `summary`, `proposedActions`, `createdAt`.
  3. The owning bot / manager flags `needsAttention = true`.
  4. User or calling system calls `approveStage(cardId:)` to proceed to the next stage, or `rejectStage(cardId:reason:)` to abort/retry.

---

## 4. Existing Test Coverage in ApexAgentTests

### 4.1 What Exists Today
1. `MultiBotParityTests.swift`:
   - `TeamPlaybookTests`: Tests JSON and Markdown encoding/decoding of `TeamPlaybook`.
   - `BotManagerPlaybookTests`: Tests `BotManager.exportPlaybook` and `BotManager.importPlaybook`.
   - `PerBotModelProviderTests`: Tests model provider assignment.
   - `GroupChatEngineRoutingTests`: Tests group chat session initialization and tool allowlisting.
2. `MultiBotParityP3Tests.swift`:
   - `ConcurrentGroupChatTests`: Tests concurrent group chat creation and lifecycle.
3. `DaemonAndPeerGateTests.swift`:
   - `PeerDeliveryGateTests`: Tests unapproved peer message gating, pending card raising, attention flag, and remembered grants.
4. `LiveBotCommunicationTests.swift`:
   - Tests live bot direct handoff and peer-gated handoff against real Foundation Models.
5. `BotLayerTests.swift`:
   - Tests `BotProfile`, `BotManager`, `BotSession`, `GroupChatModelTests`.
6. `OpenMausBotPortsTests.swift` & `OpenMausBotPorts2Tests.swift`:
   - Tests Chief of Staff system prompts, roster clipping, and peer allow keys.

### 4.2 Gaps in Test Coverage
- Zero tests for `CollaborationPlaybook` models and built-in preset definitions.
- Zero tests for automated participant assignment algorithms.
- Zero tests for sequential and parallel stage turn dispatching.
- Zero tests for stage-level approval gating and approval card resolution.
- Zero tests for live tracking of peer delegations across playbook stages.

---

## 5. Specification & Implementation Strategy for R2

### 5.1 Playbook Data Models (`CollaborationPlaybook.swift`)
Create `ApexAgent/Models/CollaborationPlaybook.swift` defining:
1. `enum PlaybookPresetKind: String, CaseIterable, Codable, Sendable`:
   - `.fullPRReviewLoop = "full_pr_review_loop"`
   - `.issueToPatchPipeline = "issue_to_patch_pipeline"`
   - `.weeklyStandupAndRetro = "weekly_standup_retro"`
2. `enum PlaybookDispatchMode: String, Codable, Sendable`:
   - `.sequential = "sequential"`
   - `.parallel = "parallel"`
3. `struct PlaybookRoleRequirement: Identifiable, Codable, Sendable`:
   - `id: String` (e.g. `"chiefOfStaff"`, `"codeArchitect"`, `"researcher"`, `"automator"`, `"apex"`)
   - `title: String`
   - `description: String`
   - `suggestedAvatar: String`
4. `struct PlaybookStageDefinition: Identifiable, Codable, Sendable`:
   - `id: String`
   - `name: String`
   - `description: String`
   - `dispatchMode: PlaybookDispatchMode`
   - `requiredRoleIds: [String]`
   - `promptTemplate: String` (supports tokens like `{input}`, `{previousOutput}`)
   - `requiresApprovalGate: Bool`
   - `approvalDescription: String?`
5. `struct CollaborationPlaybook: Identifiable, Codable, Sendable`:
   - `id: UUID`
   - `presetKind: PlaybookPresetKind?`
   - `name: String`
   - `description: String`
   - `version: String`
   - `roles: [PlaybookRoleRequirement]`
   - `stages: [PlaybookStageDefinition]`
   - Built-in static accessors:
     - `CollaborationPlaybook.builtInPresets: [CollaborationPlaybook]`
     - `CollaborationPlaybook.fullPRReviewLoop: CollaborationPlaybook`
     - `CollaborationPlaybook.issueToPatchPipeline: CollaborationPlaybook`
     - `CollaborationPlaybook.weeklyStandupAndRetro: CollaborationPlaybook`

### 5.2 Preset Specifications

#### Preset 1: Full PR Review Loop
- **Roles**:
  - `chiefOfStaff`: Coordinator & Verdict Synthesizer
  - `codeArchitect`: Code Quality, Architecture & Diff Inspector
  - `researcher`: Security, Documentation & Dependency Auditor
  - `automator`: Build, Test & Lint Verifier
- **Stages**:
  1. *Stage 1 — Dual Inspection (Parallel)*:
     - Roles: `codeArchitect`, `researcher`
     - Prompt: Architect inspects diff for correctness, design patterns, and performance; Researcher inspects security, documentation, and dependencies.
  2. *Stage 2 — Review Synthesis (Sequential)*:
     - Role: `chiefOfStaff`
     - Prompt: Synthesize Architect and Researcher findings into a coherent preliminary review report.
  3. *Stage 3 — Test Execution Gate (Approval Gate)*:
     - `requiresApprovalGate: true`
     - Prompt: Approve running automated build & test suite.
  4. *Stage 4 — Automated Verification (Sequential)*:
     - Role: `automator`
     - Prompt: Run test suite, compile check, and verify zero regressions.
  5. *Stage 5 — Final Verdict (Sequential)*:
     - Role: `chiefOfStaff`
     - Prompt: Formulate final PR verdict (Approve / Request Changes with actionable notes).

#### Preset 2: Issue-to-Patch Pipeline
- **Roles**:
  - `chiefOfStaff`: Workflow Manager
  - `researcher`: Issue Triage & Root Cause Analyst
  - `codeArchitect`: Patch Designer & Implementer
  - `automator`: Verification & Patch Applier
- **Stages**:
  1. *Stage 1 — Root Cause Triage (Sequential)*:
     - Role: `researcher`
     - Prompt: Analyze issue report, trace reproduction steps, and identify root cause files.
  2. *Stage 2 — Patch Design (Sequential)*:
     - Role: `codeArchitect`
     - Prompt: Design minimal, surgical patch and specify exact file modifications.
  3. *Stage 3 — Patch Approval Gate (Approval Gate)*:
     - `requiresApprovalGate: true`
     - Prompt: Human review of proposed patch changes before writing to disk.
  4. *Stage 4 — Apply & Verify (Sequential)*:
     - Role: `automator`
     - Prompt: Apply code edits, run build, and verify issue resolution.
  5. *Stage 5 — Issue Resolution Summary (Sequential)*:
     - Role: `chiefOfStaff`
     - Prompt: Summarize resolution, modified files, and test evidence for release notes.

#### Preset 3: Weekly Standup & Retrospective
- **Roles**:
  - `chiefOfStaff`: Standup Lead & Facilitator
  - `codeArchitect`: Engineering Lead
  - `researcher`: Knowledge & Research Lead
  - `automator`: Operations & Tooling Lead
  - `apex`: General Assistant
- **Stages**:
  1. *Stage 1 — Team Check-In (Parallel)*:
     - Roles: `codeArchitect`, `researcher`, `automator`, `apex`
     - Prompt: Each bot reports achievements from the past cycle, current blockers, and upcoming priorities.
  2. *Stage 2 — Standup Synthesis & Action Items (Sequential)*:
     - Role: `chiefOfStaff`
     - Prompt: Aggregate team reports into a prioritized weekly standup briefing with risk highlights and action items.

### 5.3 Participant Auto-Assignment Engine
Implement `PlaybookParticipantAssigner`:
- Resolves each `PlaybookRoleRequirement` to a `BotProfile` from `BotManager`:
  - `chiefOfStaff`: Selects bot with `isChiefOfStaff == true` or name containing "chief".
  - `codeArchitect`: Selects bot with name containing "architect" or "developer" or title containing "engineer".
  - `researcher`: Selects bot with name containing "researcher" or title containing "research".
  - `automator`: Selects bot with name containing "automator" or title containing "automator"/"system".
  - `apex`: Selects bot named "Apex" or falls back to the first available bot.
- Fallback: If no specialist bot is found, seamlessly falls back to available active bots or the default Apex assistant, ensuring robust zero-crash execution.

### 5.4 Playbook Runner & Execution Engine (`PlaybookRunner.swift`)
Implement `PlaybookRunner`:
- `@Observable @MainActor final class PlaybookRunner`:
  - Properties:
    - `playbook: CollaborationPlaybook`
    - `participantMap: [String: BotProfile]` (roleId -> BotProfile)
    - `currentStageIndex: Int`
    - `stageResults: [PlaybookStageResult]`
    - `status: PlaybookExecutionStatus`
    - `pendingApprovalCard: PlaybookApprovalCard?`
    - `delegationHistory: [PlaybookDelegationEvent]`
  - Execution methods:
    - `start(input: String) async throws`
    - `executeCurrentStage(stageInput: String) async throws`
    - `approvePendingStage()` async throws
    - `rejectPendingStage(reason: String)`
    - `cancel()`
  - Concurrency handling:
    - Sequential stages run consecutively.
    - Parallel stages execute concurrently via `withThrowingTaskGroup`.
    - Live updates stream to `TraceBus.shared`.

### 5.5 Comprehensive Real Functional Test Suite
Create `ApexAgentTests/PlaybookCollaborationTests.swift` testing:
1. Preset template validity and role coverage for all 3 presets.
2. Participant auto-assignment accuracy across full bot roster and partial rosters with fallbacks.
3. Sequential turn dispatching with context passing across stages.
4. Parallel turn dispatching verifying concurrent multi-bot execution.
5. Approval card gating: pausing execution, raising approval cards, resolving approval to resume, and rejection handling.
6. Delegation event tracking and `TraceBus` event emission.
7. End-to-end simulated playbook run (real functional execution without mocks or stubs).
