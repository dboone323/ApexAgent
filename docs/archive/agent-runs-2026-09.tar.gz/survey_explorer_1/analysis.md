# Technical Investigation & Analysis Report: R1 & R4

**Author**: survey_explorer_1  
**Target Areas**: 
- **R1**: Settings & Creation UI Sheets (`CreateRoutineSheet` & `CreateSkillSheet` in `ApexAgent/UI/RoutinesSection.swift` and `ApexAgent/UI/SkillsSection.swift`, SwiftData persistence for `Routine` & `Skill`, `~/.apex/skills/` file persistence).
- **R4**: Dynamic Script & MCP Server Discovery UI (Interactive MCP Server Dashboard in Settings for live connection status, latency, stdio/SSE channels, registered tools; Dynamic Script Editor view in Settings for inspecting and editing `~/.apex/skills/` scripts).

---

## 1. Executive Summary

This investigation analyzed the codebase for implementing feature requirements **R1** and **R4** in ApexAgent.

1. **R1 (Settings & Creation UI Sheets)**:
   - `ApexAgent/UI/RoutinesSection.swift` currently defines `RoutinesSection` and `RoutineRow`, but the `"Add Routine"` button is a no-op placeholder (`// TODO(p2c): wire a CreateRoutineSheet; for now no-op.`). `CreateRoutineSheet` needs to be implemented to support trigger configurations (`.manual`, `.timeInterval`, `.cron`, `.onError`, `.onSuccess`, `.onMessage`, `.webhook`), target bot assignment from `BotProfile`, cron validation via `CronSchedule`, and persistence via SwiftData `ModelContext` / `RoutineManager`.
   - `ApexAgent/UI/SkillsSection.swift` defines `SkillsSection` and `SkillRow`, but `"Add Custom Skill"` is also a no-op placeholder. Furthermore, `SkillsSection` is completely omitted from `SettingsView.swift`. `CreateSkillSheet` needs to be implemented with parameter schema validation, `.sh` executable script persistence with `chmod +x` under `~/.apex/skills/`, `.json` manifest creation, SwiftData `Skill` persistence, and runtime reload via `DynamicToolbox.shared.loadTools()` and `SkillManager.shared.syncFromDisk()`.

2. **R4 (Dynamic Script & MCP Server Discovery UI)**:
   - `ApexAgent/UI/DynamicToolboxManagerSection.swift` is currently a bare list displaying server names and raw commands with a delete button. It lacks live server health state, roundtrip latency metrics, transport channel identification (stdio vs. SSE/HTTP), and registered tools exploration.
   - `MCPClient.swift` contains the underlying stdio process supervision, circuit breaker, and JSON-RPC communication machinery (`health()`, `isCircuitOpen()`, `resetCircuit()`), but lacks a roundtrip latency probe (`pingWithLatency()` / `measureLatency()`) and a rich SwiftUI dashboard component.
   - There is currently no UI in Settings for inspecting, editing, test-running, or hot-reloading custom shell scripts (`~/.apex/skills/*.sh` and `*.json`). A dedicated `DynamicScriptEditorView` is needed to provide script selection, code editing, JSON schema inspection, live parameter test execution (with stdout/stderr console), and instant reloading into `DynamicToolbox`.

---

## 2. Deep Dive: Requirement R1 (Settings & Creation UI Sheets)

### 2.1 Routines Architecture & `CreateRoutineSheet`

#### Existing Implementation:
- **File**: `ApexAgent/UI/RoutinesSection.swift` (Lines 1–164)
  - Queries `@Query(sort: \Routine.name) private var routines: [Routine]`
  - Renders `RoutineRow` with trigger icons (`manual`: `hand.tap`, `timeInterval`: `clock`, `cron`: `calendar.badge.clock`, `onError`: `exclamationmark.triangle`, `onSuccess`: `checkmark.circle`, `onMessage`: `message`, `webhook`: `bolt`).
  - Has enabled toggle binding to `RoutineManager.shared.toggle(routine)`.
  - Has context menu with `"Run Now"` (executes asynchronously via `RoutineManager.shared.runNow(routine)`) and `"Delete"`.
  - Has `"Teach a Bot (Record Routine)"` button wired to `RoutineRecordingSheet()`.
  - Line 32–34:
    ```swift
    Button("Add Routine") {
        // TODO(p2c): wire a CreateRoutineSheet; for now no-op.
    }
    ```

- **SwiftData Model**: `ApexAgent/Models/Routine.swift` (Lines 1–64)
  ```swift
  @Model
  final class Routine {
      @Attribute(.unique) var name: String
      var descriptionText: String        // prompt / instructions
      var trigger: RoutineTrigger
      var scheduledMinutes: Int          // when trigger == .timeInterval
      var cronExpression: String?        // when trigger == .cron
      var enabled: Bool
      var createdAt: Date
      var updatedAt: Date
  }
  ```
  - `RoutineTrigger`: `.manual`, `.timeInterval`, `.cron`, `.onError`, `.onSuccess`, `.onMessage`, `.webhook`.
  - `effectiveScheduleDescription`: Uses `CronSchedule(expression:)` human-readable description or interval minutes string.

- **Execution & Routing**: `ApexAgent/Models/RoutineManager.swift` (Lines 84–118)
  - `execute(_ routine: Routine) async -> String?`
  - Parses `<BotName>: <prompt>` prefix in `routine.descriptionText`. If a matching bot exists (e.g. `Chief of Staff`, `Code Architect`, `Researcher`, `Automator`, `Apex`), it dispatches to that bot's `BotSession`. Otherwise, falls back to the default bot.

#### Detailed Design & Specification for `CreateRoutineSheet`:
1. **State & Form Fields**:
   - `routineName`: String (validation: non-empty, trimmed, unique)
   - `prompt`: String (the prompt/instruction to run; non-empty)
   - `targetBot`: `BotProfile?` or String (picker populated via `@Query(sort: \BotProfile.name) var bots: [BotProfile]` or `botManager.allBots`)
   - `selectedTrigger`: `RoutineTrigger` (picker over all cases: `.manual`, `.timeInterval`, `.cron`, `.onError`, `.onSuccess`, `.onMessage`, `.webhook`)
   - `scheduledMinutes`: Int (stepper / picker from 1 to 1440 minutes, default 15)
   - `cronExpression`: String (e.g. `0 9 * * *`, `*/15 * * * *`, `0 0 * * 1-5`)
   - `cronValidationMessage`: String? (calculated via `CronSchedule.isValid(cronExpr)` and `(try? CronSchedule(expression: cronExpr))?.humanReadableDescription`)
   - `webhookPathPreview`: String (e.g. `http://localhost:8800/api/v1/webhook/\(routineName.lowercased())`)

2. **Validation Rules**:
   - `routineName.trimmingCharacters(in: .whitespacesAndNewlines)` must not be empty.
   - `prompt.trimmingCharacters(in: .whitespacesAndNewlines)` must not be empty.
   - If `selectedTrigger == .cron`: `CronSchedule.isValid(cronExpression)` must return `true`.
   - If `selectedTrigger == .timeInterval`: `scheduledMinutes > 0`.

3. **Persistence Flow**:
   - Assemble `descriptionText`: If a target bot is selected and not `"Apex"`/default, format as `"\(botName): \(prompt)"` (or store directly as prompt if bot is default).
   - Instantiate `Routine(name: routineName, descriptionText: descriptionText, trigger: selectedTrigger, scheduledMinutes: scheduledMinutes, cronExpression: selectedTrigger == .cron ? cronExpression : nil, enabled: true)`.
   - Insert into SwiftData `modelContext.insert(routine)` and save `try? modelContext.save()`, or call `routineManager.save(routine)`.
   - Call `routineManager.loadRoutines()` to refresh the active timer/cron scheduler.

4. **UI Integration**:
   - In `RoutinesSection.swift`, add `@State private var isAddingRoutine: Bool = false`.
   - Update `"Add Routine"` button action: `isAddingRoutine = true`.
   - Add `.sheet(isPresented: $isAddingRoutine) { CreateRoutineSheet() }`.

---

### 2.2 Skills Architecture & `CreateSkillSheet`

#### Existing Implementation:
- **File**: `ApexAgent/UI/SkillsSection.swift` (Lines 1–112)
  - Queries `@Query(sort: \Skill.name) private var skills: [Skill]`
  - Renders `SkillRow` with enabled toggle and delete confirmation dialog.
  - Line 35–37:
    ```swift
    Button("Add Custom Skill") {
        // TODO(p2c): wire a CreateSkillSheet; for now no-op.
    }
    ```
  - **Issue**: `SkillsSection` is defined but NOT embedded anywhere in `SettingsView.swift`.

- **SwiftData Model**: `ApexAgent/Models/Skill.swift` (Lines 1–38)
  ```swift
  @Model
  final class Skill {
      @Attribute(.unique) var name: String
      var descriptionText: String
      var scriptPath: String
      var parameterSchemaJSON: String
      var category: String            // "procedural", "custom", "mcp"
      var enabled: Bool
      var createdAt: Date
      var updatedAt: Date
      var triggerTermsJSON: String
      var requiredCapabilitiesJSON: String
      var version: String
  }
  ```

- **Skill Management & Loading**: `ApexAgent/Models/SkillManager.swift` & `DynamicToolbox.swift`
  - `SkillManager.syncFromDisk()` looks at `~/.apex/skills/*.json` manifests.
  - `DynamicToolbox.loadTools()` scans `~/.apex/skills/` and `~/.apex/tools/` for `.json` / `.yaml` manifests, loads schemas into `dynamicTools: [String: DynamicToolEntry]`, and executes them via `/bin/zsh -c <scriptPath>` passing arguments through `APEX_ARGS` environment variable and stdin.
  - `CreateSkillTool.swift` (Lines 35–123) demonstrates the exact file generation and permission requirements:
    - Target dir: `~/.apex/skills/`
    - Sanitized skill name: `^[a-z0-9_-]+$`
    - Manifest file: `~/.apex/skills/<name>.json` containing `name`, `description`, `script_path: "~/.apex/skills/<name>.sh"`, `parameters: <parsed JSON schema>`
    - Executable script: `~/.apex/skills/<name>.sh` starting with `#!/bin/zsh`
    - Permission: `chmod +x <scriptPath>`
    - Reload: `DynamicToolbox.shared.loadTools()`

#### Detailed Design & Specification for `CreateSkillSheet`:
1. **State & Form Fields**:
   - `skillName`: String (e.g. `deploy_preview`, `summarize_diff`)
   - `skillDescription`: String (e.g. `Builds and deploys the preview build to test server`)
   - `scriptContent`: String (default template: `#!/bin/zsh\n# Custom Skill Script\n# Arguments passed in APEX_ARGS (JSON)\necho "Executing \(skillName)..."\n`)
   - `parameterSchemaJSON`: String (default JSON schema: `{\n  "type": "object",\n  "properties": {\n    "input": {\n      "type": "string",\n      "description": "Input parameter"\n    }\n  }\n}`)
   - `category`: String (default `"custom"`)
   - `allowedTools`: [String] / capability tags (optional)
   - `validationError`: String?

2. **Validation Rules**:
   - `skillName` must match `^[a-z0-9_-]+$` and not be empty.
   - `skillDescription` must not be empty.
   - `scriptContent` must not be empty.
   - `parameterSchemaJSON` must be valid JSON object (decodable as `[String: Any]`).

3. **Persistence Flow**:
   - Ensure `~/.apex/skills/` directory exists.
   - Ensure `scriptContent` starts with `#!/bin/zsh`.
   - Write `~/.apex/skills/<skillName>.sh` and set POSIX permissions `chmod +x`.
   - Write `~/.apex/skills/<skillName>.json` containing `name`, `description`, `script_path: "~/.apex/skills/\(skillName).sh"`, `parameters`.
   - Create and insert `Skill` model in SwiftData:
     ```swift
     let skill = Skill(
         name: sanitizedName,
         descriptionText: skillDescription,
         scriptPath: "~/.apex/skills/\(sanitizedName).sh",
         parameterSchemaJSON: parameterSchemaJSON,
         category: category,
         enabled: true
     )
     modelContext.insert(skill)
     try? modelContext.save()
     ```
   - Refresh runtime:
     - `DynamicToolbox.shared.loadTools()`
     - `SkillManager.shared.syncFromDisk()`

4. **UI Integration**:
   - In `SkillsSection.swift`, add `@State private var isAddingSkill: Bool = false`.
   - Update `"Add Custom Skill"` button action: `isAddingSkill = true`.
   - Add `.sheet(isPresented: $isAddingSkill) { CreateSkillSheet() }`.
   - Add `SkillsSection()` into `SettingsView.swift`!

---

## 3. Deep Dive: Requirement R4 (Dynamic Script & MCP Server Discovery UI)

### 3.1 Interactive MCP Server Dashboard

#### Existing Implementation:
- **File**: `ApexAgent/UI/DynamicToolboxManagerSection.swift`
  - Simple `ForEach(mcpManager.servers)` showing name and command, with a delete button.
- **File**: `ApexAgent/Models/MCPManager.swift`
  - `servers: [MCPServerConfig]` stored in `UserDefaults` (`apex.mcpServers`).
  - `getClient(for config: MCPServerConfig) -> MCPClient` caching `[UUID: MCPClient]`.
  - `resetClientCircuit(id: UUID)` forwards to `client.resetCircuit()`.
- **File**: `ApexAgent/Models/MCPClient.swift`
  - `health() -> MCPClientHealth` returning `serverName`, `isRunning`, `circuitOpen`, `failureCount`, `restartCountInWindow`.
  - `listTools() async throws -> [MCPToolDefinition]` listing registered tools (`name`, `description`, `inputSchema`).
  - `isCircuitOpen() async -> Bool`, `resetCircuit()`.
  - Stdio process handling with JSON-RPC over pipes.
- **File**: `Modules/MCPKit/MCPServerListener.swift` & `Modules/MCPKit/MCPClient.swift`
  - HTTP/TCP listener and client for network/SSE-style MCP servers.

#### Missing Features & R4 Requirements:
1. **Live Connection & Health Status**:
   - Status indicators:
     - `Connected / Running` (green circle)
     - `Starting / Initializing` (yellow circle)
     - `Stopped / Idle` (gray circle)
     - `Circuit Open / Degraded` (red triangle / badge)
   - Live metrics per server: Process PID (for stdio), failure count, supervisor restart count.
2. **Roundtrip Latency Monitoring**:
   - Add `measureLatency() async -> Double?` / `pingWithLatency() async -> (success: Bool, latencyMs: Double)` to `MCPClient`.
   - Measure `CFAbsoluteTimeGetCurrent()` roundtrip for a lightweight `tools/list` or ping request.
   - Display latency badge (e.g. `⚡ 12 ms` or `-- ms`).
3. **Transport Channel Breakdown**:
   - **Stdio Channel**: Executable binary (`npx`, `python3`, `node`), arguments list, cwd/workspace path, environment isolation status.
   - **SSE / HTTP Channel**: Remote / local endpoint URL (`http://localhost:...`), port, header auth status.
4. **Registered Tools Explorer**:
   - Collapsible/expandable tool drawer for each server.
   - Shows registered tools: tool name, description, required arguments, parameter schema properties.
   - Filter / search tools by name or capability.
5. **Interactive Operations**:
   - "Ping / Test Connection": Triggers a live latency probe and refreshes tool list.
   - "Reset Circuit / Reconnect": Calls `resetCircuit()` and restarts client.
   - "Start / Stop": Controls process lifecycle.
   - "Add MCP Server": Modal or inline form supporting both Stdio and SSE transports.

---

### 3.2 Dynamic Script Editor View

#### Existing Implementation:
- Shell scripts stored in `~/.apex/skills/<name>.sh` and manifests in `~/.apex/skills/<name>.json`.
- `DynamicToolbox.swift` loads dynamic tools from `~/.apex/skills/` and `~/.apex/tools/`.
- No interactive editor or inspector exists in Settings.

#### Detailed Design & Specification for Dynamic Script Editor:
1. **View Layout & Components**:
   - **Sidebar / Script List**:
     - Lists all discovered `.sh` / `.json` tools under `~/.apex/skills/` and SwiftData `Skill` models.
     - Displays script name, category badge (`custom`, `system`, `mcp`), and last modified date.
     - "New Script" button (opens `CreateSkillSheet`).
     - "Refresh Scripts" button (calls `DynamicToolbox.shared.loadTools()` and `SkillManager.shared.syncFromDisk()`).
   - **Editor Detail Panel**:
     - **Metadata Tab / Header**:
       - Script name (read-only or editable for new), description text field, category picker.
       - Parameters schema editor: JSON editor for tool parameter definition (`parameters` object with properties and types).
     - **Code Editor**:
       - Monospaced text editor (`TextEditor` with `AppTheme.Font.mono(12)`).
       - Shebang preservation (`#!/bin/zsh`).
     - **Interactive Test Runner Panel**:
       - Test JSON Arguments input field (e.g. `{"input": "test_data"}`).
       - "Run Script (Test)" button.
       - Output Console: Monospaced display showing exit code (`Exit: 0` green, `Exit: >0` red), stdout output, and stderr error trace.
     - **Action Toolbar**:
       - "Save Changes" button: Writes `.sh` and `.json` to `~/.apex/skills/`, verifies `chmod +x`, updates SwiftData `Skill` record, and reloads `DynamicToolbox`.
       - "Delete Script" button (with confirmation dialog): Deletes `.sh` and `.json` files, deletes `Skill` record from SwiftData, and reloads toolbox.
       - "Revert Changes" button: Discards unsaved edits.

2. **Execution Engine for Test Runner**:
   - Executes via `DynamicToolbox.shared.executeTool(name:jsonArguments:)` or direct `/bin/zsh -c` execution passing `APEX_ARGS` and capturing stdout/stderr pipes asynchronously.

---

## 4. Comprehensive Test Matrix & Gaps Analysis

### Existing Test Suite Review:
- `ApexAgentTests/SwiftDataPersistenceTests.swift`: tests basic schema creation and fetch for `Routine` and `Skill` models.
- `ApexAgentTests/MCPResilienceTests.swift`: tests `MCPClient` circuit open, reset circuit, health snapshot, and timeout behavior.
- `ApexAgentTests/ViewHostingTests.swift`: demonstrates real `ViewHost.host(...)` pattern for SwiftUI views without mocks or stubs.

### Test Matrix Gaps to Implement:
1. **R1 Tests**:
   - `CreateRoutineSheetTests`:
     - Test input validation (empty name, empty prompt rejected).
     - Test cron expression validation (invalid cron rejected, valid cron displays human-readable description).
     - Test timeInterval configuration (minutes > 0).
     - Test target bot assignment and formatted prompt generation.
     - Test SwiftData insertion and verification that `RoutineManager` loads the created routine.
     - Test view hosting via `ViewHost.host(CreateRoutineSheet())`.
   - `CreateSkillSheetTests`:
     - Test input validation (validating regex `^[a-z0-9_-]+$`, JSON schema parse).
     - Test file generation (`.json` manifest + `.sh` script with shebang) in a temporary directory or `~/.apex/skills/`.
     - Test `chmod +x` executable bit is applied.
     - Test SwiftData `Skill` persistence and query.
     - Test dynamic tool registration in `DynamicToolbox.shared.dynamicTools`.
     - Test view hosting via `ViewHost.host(CreateSkillSheet())`.

2. **R4 Tests**:
   - `MCPServerDashboardTests`:
     - Test live health reporting (`isRunning`, `circuitOpen`, `failureCount`).
     - Test latency measurement (`pingWithLatency` / `measureLatency`) returning valid millisecond timings.
     - Test registered tool listing per server (`listTools()`).
     - Test circuit reset action from manager to client.
     - Test view hosting via `ViewHost.host(MCPServerDashboardView())`.
   - `DynamicScriptEditorTests`:
     - Test script file inspection (reading `.sh` and `.json` files).
     - Test script editing and saving back to disk.
     - Test live test run execution capturing stdout/stderr.
     - Test dynamic toolbox hot-reloading after save and delete operations.
     - Test view hosting via `ViewHost.host(DynamicScriptEditorView())`.

---

## 5. File Inventory & Proposed Modifications

| File Path | Status | Planned Modifications |
|---|---|---|
| `ApexAgent/UI/RoutinesSection.swift` | Existing | Implement `CreateRoutineSheet`, add sheet presentation binding in `RoutinesSection`. |
| `ApexAgent/UI/SkillsSection.swift` | Existing | Implement `CreateSkillSheet`, add sheet presentation binding in `SkillsSection`. |
| `ApexAgent/UI/SettingsView.swift` | Existing | Add `SkillsSection()`, embed new `MCPServerDashboardView` and `DynamicScriptEditorView`. |
| `ApexAgent/UI/DynamicToolboxManagerSection.swift` | Existing | Upgrade into rich interactive MCP Server Dashboard (`MCPServerDashboardView`) with status, latency, channels, and tool explorer. |
| `ApexAgent/UI/DynamicScriptEditorView.swift` | New | Create dedicated Dynamic Script Editor view with script browser, code editor, JSON manifest editor, and live test runner. |
| `ApexAgent/Models/MCPClient.swift` | Existing | Add `pingWithLatency() async -> (success: Bool, latencyMs: Double)` / `measureLatency() async -> Double?`. |
| `ApexAgent/Models/MCPManager.swift` | Existing | Add support for transport channel configuration, server restart/ping helpers. |
| `ApexAgentTests/SettingsSheetsAndDiscoveryTests.swift` | New | Comprehensive real functional test suite covering `CreateRoutineSheet`, `CreateSkillSheet`, `MCPServerDashboard`, and `DynamicScriptEditor`. |

