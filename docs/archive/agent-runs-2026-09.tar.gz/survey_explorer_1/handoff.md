# Handoff Report: Survey Explorer 1 (R1 & R4)

**Agent**: `survey_explorer_1`  
**Working Directory**: `/Users/danielstevens/Developer/ApexAgent/.agents/survey_explorer_1`  
**Parent Agent**: `parent` (`2989d77c-ca8b-45f8-827e-6efddad87995`)  
**Scope**: 
- **R1**: Settings & Creation UI Sheets (`CreateRoutineSheet` & `CreateSkillSheet`, SwiftData persistence, `~/.apex/skills/` file persistence).
- **R4**: Dynamic Script & MCP Server Discovery UI (Interactive MCP Server Dashboard in Settings, Dynamic Script Editor view in Settings for `~/.apex/skills/`).

---

## 1. Observation

### Source Code Findings:
1. **`ApexAgent/UI/RoutinesSection.swift` (lines 32–34)**:
   - Contains a placeholder for `CreateRoutineSheet`:
     ```swift
     Button("Add Routine") {
         // TODO(p2c): wire a CreateRoutineSheet; for now no-op.
     }
     ```
   - Renders `RoutineRow` with trigger icons and schedule descriptions.
   - `RoutineManager.swift` (lines 84–118) executes routines and dispatches to specific bots based on `<BotName>: <prompt>` prefixes in `descriptionText`.

2. **`ApexAgent/UI/SkillsSection.swift` (lines 35–37)**:
   - Contains a placeholder for `CreateSkillSheet`:
     ```swift
     Button("Add Custom Skill") {
         // TODO(p2c): wire a CreateSkillSheet; for now no-op.
     }
     ```
   - `SkillsSection` is not placed in `SettingsView.swift`.

3. **`ApexAgent/UI/SettingsView.swift` (lines 493–497)**:
   - Currently includes `DynamicToolboxManagerSection()` and `RoutinesSection()`, but omits `SkillsSection()`.

4. **`ApexAgent/UI/DynamicToolboxManagerSection.swift` (lines 12–31)**:
   - Bare list displaying `config.name` and command strings with a trash button.
   - No connection health indicator, latency metrics, transport channels (stdio vs. SSE/HTTP), or registered tools list.

5. **`ApexAgent/Models/MCPClient.swift` (lines 455–464, 530–563, 647–651)**:
   - Implements `health() -> MCPClientHealth`, `ping() async -> Bool`, `isCircuitOpen() async -> Bool`, `resetCircuit()`, and `listTools() async throws -> [MCPToolDefinition]`.
   - Stdio process JSON-RPC 2.0 communication is fully functional, but lacks a roundtrip latency probe method (`measureLatency()` / `pingWithLatency()`).

6. **`ApexAgent/Models/DynamicToolbox.swift` (lines 23–149, 194–273)**:
   - Scans and dynamically loads tools from `~/.apex/skills/*.json` and `~/.apex/skills/*.sh`.
   - Executes dynamic scripts using `/bin/zsh -c` passing arguments via `APEX_ARGS` and stdin.
   - No UI exists in Settings for inspecting, editing, or test-running these custom scripts.

7. **`ApexAgentTests/ViewHostingTests.swift` (lines 13–35)**:
   - Demonstrates the real SwiftUI view hosting pattern (`ViewHost.host(view)`) without mocks or stubs.

---

## 2. Logic Chain

1. **R1 Logic**:
   - `CreateRoutineSheet` must provide form inputs for routine name, prompt text, target bot assignment (`BotProfile`), trigger selection (`RoutineTrigger`: `.manual`, `.timeInterval`, `.cron`, `.onError`, `.onSuccess`, `.onMessage`, `.webhook`), interval minutes, and cron expressions.
   - Because `RoutineManager.execute(_:)` determines target bot execution by parsing `<BotName>: <prompt>`, `CreateRoutineSheet` can format the routine prompt to seamlessly route execution to the selected bot.
   - Because `CronSchedule.isValid(cronExpr)` exists in `CronParser.swift`, live cron validation and human-readable preview can be provided immediately in the sheet.
   - `CreateSkillSheet` must validate sanitized skill names (`^[a-z0-9_-]+$`), write executable `.sh` files with `chmod +x` and `.json` manifests under `~/.apex/skills/`, insert `Skill` models into SwiftData, and call `DynamicToolbox.shared.loadTools()` and `SkillManager.shared.syncFromDisk()` to hot-reload tools into active sessions.
   - `SkillsSection` must be embedded into `SettingsView.swift` alongside `RoutinesSection`.

2. **R4 Logic**:
   - For MCP Server Discovery, `MCPClient` can measure roundtrip request duration (in ms) using `CFAbsoluteTimeGetCurrent()`.
   - An interactive `MCPServerDashboardView` replacing `DynamicToolboxManagerSection` can query `client.health()`, measure live latency, display transport channels (stdio command/args/supervision vs SSE/HTTP endpoints), list discovered tools (`client.listTools()`), and offer connection actions (Ping, Restart/Reset Circuit, Add/Delete).
   - For Dynamic Scripts, a dedicated `DynamicScriptEditorView` in Settings can read custom script files from `~/.apex/skills/`, display a monospaced code editor, allow parameter schema editing, provide an interactive test runner with live stdout/stderr console, and save updates back to disk and SwiftData.

---

## 3. Caveats

1. **Environment Variables**: Dynamic script tools receive arguments via `APEX_ARGS` and stdin; custom scripts must properly accept JSON strings or parse them with `jq` / `zsh`.
2. **Apple Container & Sandbox Boundary**: When running under restricted folder access, scripts execute with `HOME` set to `~/.apex/sandbox`. Tests must be aware of sandboxing constraints.
3. **No Mocks Principle**: All unit and integration tests must test real functional behavior using real SwiftData containers (`isStoredInMemoryOnly: true` or temporary disk stores), real filesystem file writes/reads, and real `ViewHost.host` view rendering.

---

## 4. Conclusion

- R1 and R4 have clear architectural hooks in `ApexAgentCore` and require UI components and model wiring.
- Implementing `CreateRoutineSheet`, `CreateSkillSheet`, `MCPServerDashboardView`, and `DynamicScriptEditorView` along with comprehensive real functional tests will fully satisfy requirements R1 and R4.
- All technical specifications and code structures are documented in detail in `analysis.md`.

---

## 5. Verification Method

To independently verify findings and implementations:
1. **Source Inspection**:
   - Inspect `ApexAgent/UI/RoutinesSection.swift` (line 33) and `ApexAgent/UI/SkillsSection.swift` (line 36) for TODO placeholders.
   - Inspect `ApexAgent/UI/SettingsView.swift` to verify `SkillsSection` absence and `RoutinesSection` placement.
   - Inspect `ApexAgent/Models/MCPClient.swift` and `DynamicToolbox.swift` for dynamic loading and execution capabilities.
2. **Functional Test Execution**:
   - Run `swift test --filter SwiftDataPersistenceTests`
   - Run `swift test --filter MCPResilienceTests`
   - Run `swift test --filter ViewHostingTests`
   - Build full project: `swift build`

