# Adopted Frameworks Reference Directory

Place high-quality reference markdown documentation files here.
The `search_docs.py` script will scan this directory to pull relevant documentation content into the context.

## Example File Formatting:
Files should be formatted in standard Markdown with clean header hierarchies so that search matches resolve to clear context.

- [Next.js Patterns](file:///Users/danielstevens/.gemini/config/skills/adopted_frameworks/references/nextjs_patterns.md)
- [ApexAgent Sync Guidelines](file:///Users/danielstevens/.gemini/config/skills/adopted_frameworks/references/apex_agent_sync.md)
