#!/usr/bin/env python3
import os
import sys
import re
import argparse

def search_documents(query, is_regex=False, case_insensitive=True):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    references_dir = os.path.abspath(os.path.join(script_dir, "..", "references"))
    
    if not os.path.exists(references_dir):
        print(f"References directory not found: {references_dir}")
        return []

    results = []
    
    flags = re.IGNORECASE if case_insensitive else 0
    
    for root, _, files in os.walk(references_dir):
        for file in files:
            if not file.endswith(".md"):
                continue
            filepath = os.path.join(root, file)
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                
                for line_idx, line in enumerate(lines, 1):
                    matched = False
                    if is_regex:
                        try:
                            if re.search(query, line, flags):
                                matched = True
                        except re.error as e:
                            print(f"Regex error: {e}", file=sys.stderr)
                            sys.exit(1)
                    else:
                        target = query.lower() if case_insensitive else query
                        current_line = line.lower() if case_insensitive else line
                        if target in current_line:
                            matched = True
                    
                    if matched:
                        results.append({
                            "file": filepath,
                            "line_number": line_idx,
                            "content": line.strip()
                        })
            except Exception as e:
                print(f"Error reading file {filepath}: {e}", file=sys.stderr)

    return results

def main():
    parser = argparse.ArgumentParser(description="Search adopted framework documentation.")
    parser.add_argument("query", help="Search term or regex pattern")
    parser.add_argument("--regex", action="store_true", help="Treat query as regular expression")
    parser.add_argument("--case-sensitive", action="store_true", help="Perform case-sensitive search")
    
    args = parser.parse_args()
    
    results = search_documents(args.query, is_regex=args.regex, case_insensitive=not args.case_sensitive)
    
    if not results:
        print(f"No matches found for: '{args.query}'")
        return
        
    print(f"Found {len(results)} matches:\n")
    for r in results:
        # Generate markdown link
        abs_path = os.path.abspath(r['file'])
        filename = os.path.basename(abs_path)
        print(f"- [{filename}](file://{abs_path}#L{r['line_number']}): Line {r['line_number']} - {r['content']}")

if __name__ == "__main__":
    main()
