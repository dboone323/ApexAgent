#!/usr/bin/env python3
import os
import subprocess
import unittest

class TestSearchDocs(unittest.TestCase):
    def setUp(self):
        self.script_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "search_docs.py"
        )
        # Ensure script is executable
        os.chmod(self.script_path, 0o755)

    def test_search_readme(self):
        # Query for "Reference Directory" which is in README.md
        result = subprocess.run(
            [self.script_path, "Reference Directory"],
            capture_output=True,
            text=True
        )
        self.assertEqual(result.returncode, 0)
        self.assertIn("README.md", result.stdout)
        self.assertIn("Reference Directory", result.stdout)

    def test_search_not_found(self):
        result = subprocess.run(
            [self.script_path, "NonExistentWordXYZ123"],
            capture_output=True,
            text=True
        )
        self.assertEqual(result.returncode, 0)
        self.assertIn("No matches found for: 'NonExistentWordXYZ123'", result.stdout)

if __name__ == "__main__":
    unittest.main()
