## 2026-08-27T20:15:06Z
You are worker_m1 assigned to Milestone M1 (Settings & Creation UI Sheets: CreateRoutineSheet & CreateSkillSheet).

Working directory: /Users/danielstevens/Developer/ApexAgent/.agents/worker_m1
Read:
- /Users/danielstevens/Developer/ApexAgent/.agents/ORIGINAL_REQUEST.md
- /Users/danielstevens/Developer/ApexAgent/PROJECT.md
- /Users/danielstevens/Developer/ApexAgent/.agents/survey_explorer_1/analysis.md

MANDATORY INTEGRITY WARNING:
DO NOT CHEAT. All implementations must be genuine. DO NOT hardcode test results, create dummy/facade implementations, or circumvent the intended task. A auditor will independently verify your work. Integrity violations WILL be detected and your work WILL be rejected.

Testing Principle: All tests must be implemented using REAL functional code that performs real validations. Never use mocks, placeholders, stubs, or dummy/fake tests.

Exclusive File Ownership:
- ApexAgent/UI/RoutinesSection.swift
- ApexAgent/UI/SkillsSection.swift
- ApexAgent/UI/SettingsView.swift
- ApexAgentTests/CreationSheetsTests.swift

Tasks:
1. In `ApexAgent/UI/RoutinesSection.swift`:
   - Implement `CreateRoutineSheet` with form fields for routine name, prompt/description, target bot picker (populated from `BotProfile` / `BotManager`), trigger picker (`.manual`, `.timeInterval`, `.cron`, `.onError`, `.onSuccess`, `.onMessage`, `.webhook`), interval minutes stepper, cron expression input with live validation using `CronSchedule`, and webhook path preview.
   - Wire the "Add Routine" button to present `CreateRoutineSheet`.
   - Validate non-empty inputs and valid cron syntax before enabling the Save button.
   - On save: assemble target bot prefix if non-default, insert `Routine` into SwiftData `modelContext`, save context, and call `RoutineManager.shared.loadRoutines()`.
2. In `ApexAgent/UI/SkillsSection.swift`:
   - Implement `CreateSkillSheet` with form fields for skill name, description, allowed tools selection, parameter schema builder/editor, and executable shell script content.
   - Wire the "Add Custom Skill" button to present `CreateSkillSheet`.
   - On save: write executable `.sh` script (`chmod 0755`) and `.json` manifest to `~/.apex/skills/`, insert `Skill` into SwiftData, and reload via `DynamicToolbox.shared.loadTools()` and `SkillManager.shared.syncFromDisk()`.
3. In `ApexAgent/UI/SettingsView.swift`:
   - Ensure `SkillsSection()` is included in the Settings view tabs/sections alongside `RoutinesSection()` and `DynamicToolboxManagerSection()`.
4. In `ApexAgentTests/CreationSheetsTests.swift`:
   - Write comprehensive real functional unit and integration tests for `CreateRoutineSheet` and `CreateSkillSheet` logic, trigger validation, cron validation, target bot dispatch formatting, SwiftData persistence, and `~/.apex/skills/` script writing and loading.
5. Build and verify:
   - Run `swift build` and `swift test --filter CreationSheetsTests` (and full `swift test`). Ensure zero warnings and 100% tests pass.

Write your report to /Users/danielstevens/Developer/ApexAgent/.agents/worker_m1/handoff.md and notify caller.
