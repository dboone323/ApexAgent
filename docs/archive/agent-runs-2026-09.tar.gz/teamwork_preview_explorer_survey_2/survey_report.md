# ApexAgent Comprehensive Architecture & Subsystem Survey Report
**Author**: Explorer 2 (Teamwork Explorer Agent)  
**Target Workspace**: `/Users/danielstevens/Developer/ApexAgent`  
**Date**: 2026-08-26  
**Scope**: Bot Roster, LLM Engine Backends, Multi-Agent Coordination, and Tool Registry & Dispatch.

---

## 1. Executive Summary & Architectural Overview

ApexAgent is a multi-agent macOS desktop application written in modern Swift (targeting macOS 27 and Swift 6.4 strict concurrency). It provides an AI teammate environment featuring:
- **Durable Bot Teammates**: Distinct personas with dedicated conversational histories, long-term memory, and tool permissions sharing the local Mac environment.
- **Pluggable Multi-Engine LLM Tier**: First-class support for Native Apple Foundation Models ( framework, on-device AFM 3 and Private Cloud Compute), local Open Source models via Local Ollama (HTTP/NDJSON) and Local MLX (OpenAI SSE wire format), as well as Apple’s `fm` CLI and Cloud Gemini.
- **Hierarchical & Lateral Multi-Agent Coordination**: Group chat collaboration, executive Chief of Staff dynamic roster synthesis, task delegation handoffs, multi-round panel meeting debates, and state-graph execution workflows.
- **Multi-Layered Tool Safety & Sandboxing**: Global actor-isolated execution (`@ToolActor`), 3-tier risk classification, human confirmation gating, regex backstops for destructive/sensitive commands, file-write rollbacks (`.apex-bak`), and indirect prompt-injection sanitization.

---

## 2. Focus Area 1: Bot Roster Implementation & Configuration

### 2.1 Data Models & State Architecture

The Bot layer is centered around SwiftData-persisted profiles and ephemeral memory models:

1. **`BotProfile` (`ApexAgent/Models/BotProfile.swift`)**:
   - Persisted in SwiftData via `@Model final class BotProfile`.
   - **Key Properties**:
     - `id: UUID`: Unique identifier.
     - `name: String`, `title: String`: Display name and short role tag (e.g. "Senior Engineer").
     - `descriptionText: String`: Operational instructions and behavioral rules.
     - `avatarName: String`: SF Symbol name for UI rendering (e.g. `"bolt.fill"`, `"chevron.left.forwardslash.chevron.right"`).
     - `memory: String`: Durable working preferences and context accumulated across turns.
     - `isPinned: Bool`, `lastActiveAt: Date`: Sorting and sidebar attention states.
     - `isChiefOfStaff: Bool`: Flag designating the bot as an executive coordinator with live team roster interpolation.
     - `modelProviderRaw: String?`: Per-bot provider override (maps to `ModelProvider`).
     - `ollamaModelOverride: String?`: Per-bot model override for Ollama (e.g. `"deepseek-r1:14b"` vs global default).
   - **System Instruction Assembly (`systemInstructions`)**:
     Combines title, operational instructions, and durable memory:
     ```swift
     var systemInstructions: String {
         var parts: [String] = []
         if !title.isEmpty { parts.append("You are \(name). \(title)") }
         else { parts.append("You are \(name).") }
         if !descriptionText.isEmpty { parts.append(descriptionText) }
         if !memory.isEmpty { parts.append("\n\n--- Durable working context ---\n\(memory)") }
         return parts.joined(separator: "\n\n")
     }
     ```

2. **`BotMemoryEntry` (`ApexAgent/Models/BotProfile.swift`)**:
   - Discrete memory records with `key`, `value`, `source` (e.g. "user instruction"), and `botProfileId`.

3. **`BotSession` (`ApexAgent/Models/BotSession.swift`) & `BotSessionState`**:
   - Scoped in-memory session maintaining conversation history (`[ChatMessage]`), active tool events (`[ToolEvent]`), streaming status (`isGenerating`), pending confirmation requests, and the underlying `LanguageModelSession`.

4. **`BotManager` (`ApexAgent/Models/BotManager.swift`)**:
   - Central registry managing all bot profiles and active sessions.
   - Manages active conversation switching, message dispatch (`sendMessage`, `sendMessageTo`), attention tracking (`botsNeedingAttention`), peer approval mediation, and team playbook export/import.

---

### 2.2 Core Bot Roster & Personas

The default built-in roster seeded by `BotManager.loadBotsFromDisk()` and `AgentRegistry.builtInDefaults` includes:

| Bot Name | Title / Archetype | Icon | Core Mission & Behavioral Parameters | Default Tool Permissions |
| :--- | :--- | :--- | :--- | :--- |
| **Apex** | General Assistant | `bolt.fill` | General everyday assistance, command orchestration, file search, and Mac task automation. | Full tool access via `allTools` / Orchestrator. |
| **Chief of Staff** | Executive Coordinator | `person.crop.square.fill` | Workflow decomposition, specialist delegation, outcome synthesis. `isChiefOfStaff = true`. | `delegate_task`, `convene_meeting`, `update_plan`, `send_notification`. |
| **Code Architect** *(Codex)* | Senior Engineer | `chevron.left.forwardslash.chevron.right` | Codebase analysis, architectural planning, code authoring/refactoring, debugging, Swift/macOS development. | `read_file`, `write_file`, `list_directory`, `create_directory`, `delete_file`, `move_file`, `audit_projects`, `create_skill`, `run_shell_command`, `analyze_image`. |
| **Researcher** *(Oracle)* | Deep Research Specialist | `magnifyingglass` | Web crawling, documentation analysis, citation-grounded synthesis, technical reporting. | `web_search`, `read_clipboard`, `write_clipboard`, `read_file`, `list_directory`, `take_screenshot`. |
| **Automator** *(Nexus)* | macOS System Automator | `terminal.fill` | Shell execution, AppleScript/Shortcuts scripting, build verification, app automation. | `run_shell_command`, `run_applescript`, `control_app`, `control_accessibility`. |

#### Additional Registered Sub-Agents (`AgentRegistry` / `AgentProfiles`):
- **Pilot (Controller)**: Active UI interaction, browser automation, process inspection, clipboard management. Tools: `get_frontmost_app`, `get_running_processes`, `read_clipboard`, `write_clipboard`, `send_notification`, `control_accessibility`, `control_app`, `control_browser`.
- **Auditor (Linter)**: Syntax auditing, SwiftLint compliance, formatting, warning cleanups. Tools: `read_file`, `write_file`, `list_directory`, `run_shell_command`, `audit_projects`.
- **Aura (UI Designer)**: SwiftUI visual layout, spacing, alignment, color tokens, aesthetic inspection. Tools: `read_file`, `write_file`, `take_screenshot`, `run_shell_command`, `run_applescript`, `control_app`.
- **Chronos (Planner)**: Goal decomposition, step-by-step roadmap management, milestone tracking. Tools: `read_file`, `write_file`, `list_directory`, `update_plan`, `store_memory`, `search_memory`.

---

### 2.3 Chief of Staff Live Roster Interpolation

When `isChiefOfStaff == true`, `BotSession.systemInstructions` dynamically invokes `ChiefOfStaff.systemPrompt` (`ApexAgent/Models/ChiefOfStaff.swift`).
- **Dynamic Context Injection**: Every turn, the Chief of Staff’s system prompt is formatted with the live list of team members, their roles, descriptions, and current availability (`busy` / `available`).
- **Token Bounds & Truncation Caps**:
  - `rosterMaxBots = 40` (overflow listed as "…and N more")
  - `nameMax = 80` characters
  - `roleMax = 120` characters
  - `aboutMax = 200` characters
- **Team Portability**: `TeamPlaybook` (`TeamPlaybook.swift`) supports JSON/Markdown serialization and URL-based imports/exports of full multi-bot teams.

---

## 3. Focus Area 2: Backend LLM Engines

ApexAgent implements Apple’s WWDC26 unified `LanguageModel` / `LanguageModelExecutor` architecture with pluggable backends and custom direct HTTP fallback engines.

```
                     ┌───────────────────────────────┐
                     │         ModelRegistry         │
                     │  (activeProvider / effective) │
                     └───────────────┬───────────────┘
                                     │
           ┌─────────────────────────┼─────────────────────────┐
           ▼                         ▼                         ▼
  ┌──────────────────┐      ┌──────────────────┐      ┌──────────────────┐
  │ NativeAppleEngine│      │ OllamaAgentEngine│      │  MLXAgentEngine  │
  │ (AFM 3 / PCC /   │      │ (Direct HTTP     │      │ (OpenAI SSE      │
  │  LanguageModel)  │      │  NDJSON stream)  │      │  Stream /v1)     │
  └──────────────────┘      └──────────────────┘      └──────────────────┘
```

### 3.1 Native Apple Foundation Models
- **Implementation**: `NativeAppleEngine` (`AgentEngine.swift`), `SystemLanguageModel.default`, `PrivateCloudComputeLanguageModel`.
- **Session Lifecycle & Observability**:
  - Profile customization via `LanguageModelSession.DynamicProfile`.
  - Decorated with `apexAuditHooks()` (`AgentProfiles.swift`):
    - `onActivate` / `onDeactivate`: Emits signposts and OS logs.
    - `onPrompt` / `onResponse`: Logs turn text.
    - `onToolCall` / `onToolOutput`: Intercepts calls, emits signpost intervals, logs to `AgentAuditLog`.
    - `historyTransform { apexScrubHistory(/bin/zsh) }`: Scrubs historical turns for indirect injection patterns and trims history to last 20 entries.
- **Multimodal Vision Detection**:
  - `isMultimodalAttachmentSupported()` performs runtime dynamic linking verification (`dlsym`) for `FoundationModels.Attachment` constructor symbols to prevent crash on OS builds lacking symbol support.
- **Beta Skew Resilience**:
  - On macOS 27 beta 4 where `streamResponse` could hang indefinitely, `NativeAppleEngine` invokes `session.respond(to:options:)` directly and updates the active message state immediately.

---

### 3.2 Local Ollama Engine
- **Implementation**:
  - Conformer: `LocalOllamaLanguageModel` (`LocalOllamaLanguageModel.swift`) conforming to `LanguageModel`.
  - Direct Engine: `OllamaAgentEngine` (`OllamaAgentEngine.swift`).
- **Connection & Protocol Logic**:
  - Connects to Ollama host (`http://localhost:11434`) via `POST /api/chat`.
  - Streams NDJSON lines asynchronously via `URLSession.shared.bytes`.
  - Maps chat transcript (`system`, `user`, `assistant`, `tool`).
- **Dynamic Tool Calling Loop**:
  - Extracts tool schemas via `getParsedSchemas()` and formats them as OpenAI/Ollama function definitions: `{"type": "function", "function": schema}`.
  - Parses streaming `tool_calls` in JSON deltas.
  - Multi-step execution loop (up to 8 loops): executes tool via `orchestrator.allTools`, appends tool output message with role `"tool"`, and continues generation until completion.
- **Error Handling**:
  - Clear HTTP status checking (distinguishes connection failure vs un-pulled model).
  - Model fallback from per-bot `ollamaModelOverride` to global default (`gemma4:12b` or `qwen2.5-coder:latest`).

---

### 3.3 Local MLX Engine
- **Implementation**:
  - Conformer: `LocalMLXLanguageModel` (`LocalMLXLanguageModel.swift`).
  - Direct Engine: `MLXAgentEngine` (`MLXAgentEngine.swift`).
- **Connection & Protocol Logic**:
  - Connects to MLX-LM server (`http://127.0.0.1:8080`) via `POST /v1/chat/completions`.
  - Streams Server-Sent Events (SSE) (`data: { ... }`).
  - Parses and reassembles indexed tool call fragments across streaming chunks: `fragments: [Int: (id, name, arguments)]`.
- **Health Check**:
  - `LocalMLXLanguageModel.isAvailable(hostURL:)` probes `GET /v1/models` with a 2-second timeout.
- **Tool Dispatch**:
  - Multi-turn re-invocation loop (up to 8 steps) feeding OpenAI-format function output back to the model.

---

### 3.4 Additional Adapters & Model Registry
- **Apple `fm` CLI (`FMCLILanguageModel.swift`)**: Conforms to `LanguageModel` by spawning `/usr/bin/fm respond --model system|pcc --stream` with stdout async byte streaming.
- **Cloud Gemini (`CloudGeminiLanguageModel.swift`)**: Direct REST/SSE executor with schema transformation (converting property types to uppercase `STRING`, `INTEGER`, `BOOLEAN`, `OBJECT`).
- **`ModelRegistry` (`ModelRegistry.swift`)**:
  - Resolves providers: `.appleOnDevice`, `.applePCC`, `.cloudGemini`, `.localOllama`, `.localMLX`, `.fmCLI`.
  - Resolves per-bot overrides vs global UserDefaults (`apex.modelProvider`).
  - Provides `automaticChain()` fallback list.

---

## 4. Focus Area 3: Multi-Agent Coordination

ApexAgent provides three distinct coordination modalities: Group Chats, Task Delegation, and Panel Meetings.

```
                            ┌────────────────────────┐
                            │   AgentOrchestrator    │
                            └───────────┬────────────┘
                                        │
             ┌──────────────────────────┼──────────────────────────┐
             ▼                          ▼                          ▼
   ┌──────────────────┐       ┌──────────────────┐       ┌──────────────────┐
   │ GroupChatSession │       │ DelegateTaskTool │       │ConveneMeetingTool│
   │ (Round-robin     │       │ (Single-special- │       │ (Multi-round     │
   │  group chat)     │       │  ist delegation) │       │  panel debate)   │
   └─────────┬────────┘       └─────────┬────────┘       └─────────┬────────┘
             │                          │                          │
             ▼                          ▼                          ▼
   ┌────────────────────────────────────────────────────────────────────────┐
   │       Coordination Safety: TurnWatchdog, RepeatDetector,               │
   │            PeerApprovalCoordinator, StateGraph, TraceBus               │
   └────────────────────────────────────────────────────────────────────────┘
```

### 4.1 Concurrent Group Chat Sessions
- **Classes**: `GroupChatSession` and `GroupChatManager` (`GroupChat.swift`).
- **Session Mechanics**:
  - Multiple bots participate in a shared session (`participants: [BotProfile]`).
  - Turn-taking uses round-robin orchestration (`generationOrder: [UUID]`, `currentTurnIndex`, `advanceTurn()`).
  - Ephemeral and concurrent: `GroupChatManager` can manage multiple active group sessions simultaneously.
  - Per-bot engine resolution: each participant bot runs using its own configured engine (`resolveEngine(for:orchestrator:)`).
  - Context building: `buildGroupContext(for:)` formats all preceding turns with `[User]`, `[Assistant]`, `[System]` tags.
  - Real-time UI indicator: adds a live streaming thinking marker `[\(bot.name) is thinking...]` while generating.
- **Group Tool Action Governance**:
  - Safe default allowlist: `DefaultGroupToolAllowlist.set` (`web_search`, `read_file`, `list_directory`, `file_search`, `search_memory`, `store_memory`, `get_system_info`, `send_notification`).
  - Risky group tools (`run_shell_command`, `write_file`, `delete_file`, `move_file`, `run_applescript`) trigger human confirmation gating before execution.

---

### 4.2 Task Delegation Handoffs
- **Implementation**: `DelegateTaskTool` (`DelegateTaskTool.swift`) & `AgentHandoff.swift`.
- **Workflow**:
  1. Supervisor calls `delegate_task(agentType: taskDescription:)`.
  2. `activeDelegationDepth` task-local guard prevents recursive delegation loops (depth cap = 2).
  3. `createSubAgentSession` strips delegation tools (`delegate_task`, `convene_meeting`) from sub-agent sessions so specialists focus solely on domain tools.
  4. Structured Handoff Tracking: records `TaskResult(taskId:status:resultSummary:errorDetails:)` to `AgentRegistry.recordHandoff(_:)` for dashboard and audit reconciliation.

---

### 4.3 Panel Meeting Debates
- **Implementation**: `ConveneMeetingTool` (`ConveneMeetingTool.swift`).
- **Workflow**:
  1. Supervisor calls `convene_meeting(topic: participants:)`.
  2. Executes 2 full discussion rounds across all invited specialist agents.
  3. Hydrates each agent’s session with dynamic `MeetingTurn` history (pruned to 1,500 chars to conserve context window).
  4. Each participant contributes statements sequentially, updating the chat UI live.
  5. Records a structured `ConsensusReport(consensusDecision:majorityView:minorityDissent:confidence:)` to `AgentRegistry.recordConsensus(_:)`.

---

### 4.4 Coordination Safety, Watchdogs & Governance

1. **Stall Detection (`TurnWatchdog.swift`)**:
   - Activity-based watchdog that tracks `lastEventAt` per thread rather than total elapsed duration.
   - Turns waiting for human approval (`setWaitingOnHuman(threadId:waiting:true)`) are exempt from stalls.
   - Stalled turns trigger `onStall` recovery callbacks.

2. **Loop Detection (`RepeatDetector.swift`)**:
   - Computes canonical call keys: `RepeatCallKey.make(tool:arguments:)` with normalized whitespace.
   - Counts repeats per thread using an LRU cache (bounded to 256 keys).
   - Alerts when repeat counts hit configured thresholds (e.g. 3 and 5 repetitions).

3. **Peer Approval Coordinator (`PeerApproval.swift`)**:
   - Gates bot-initiated inter-bot communication (`ask_bot`, `delegate_bot`).
   - Requires user confirmation card unless an explicit grant key (`action:targetBotId`) has been remembered ("Always allow").
   - Auto-expires pending requests after 15 minutes.

4. **StateGraph Pipeline Execution (`StateGraph.swift`)**:
   - Explicit directed acyclic graph execution for multi-stage pipelines (e.g. Codex -> Auditor -> Nexus).
   - Cycle detection (`visitedNodes`) and safety iteration limits (max 100).

5. **TraceBus & Unified Tracing (`TraceBus.swift` & `Tracing.swift`)**:
   - Thread-safe ring buffer (`maxEvents = 400`) broadcasting `TraceEvent` via `AsyncStream`.
   - `Tracing.span()` records synchronously across `os_signpost` (Instruments), Apple Unified Log (`Logger`), and `TraceBus`.

---

## 5. Focus Area 4: Tool Registry & Dispatch

ApexAgent features a rich library of 30+ tools registered in `AgentOrchestrator.allTools` and `DynamicToolbox`.

```
┌────────────────────────────────────────────────────────────────────────┐
│                          Tool Invocation Gate                          │
│                                                                        │
│  1. Global Actor Isolation: @ToolActor                                 │
│  2. Turn Tool Limit: activeTurnToolCallCount <= 20                    │
│  3. Global App Policy: ToolPolicy.isGloballyAllowed(name)              │
│  4. Risk Classification: AgentSecurity.riskLevel(name)                 │
│  5. Approval Policy: ApprovalPolicy.verdict(tool, summary)             │
│  6. Confirmation Overlay: UI modal for high-risk tools                │
│  7. Pre-mutation Snapshot: FileRollback.snapshot(path)                 │
│  8. Output Truncation: 3,000 char limit                                │
│  9. Injection Defense: sanitizeForPromptInjection(output)              │
│ 10. Audit Logging: AgentAuditLog.record(...)                           │
└────────────────────────────────────────────────────────────────────────┘
```

### 5.1 Tool Catalog

| Category | Tools | Descriptions & Capabilities | Risk Level |
| :--- | :--- | :--- | :--- |
| **FileSystem** | `read_file`, `write_file`, `list_directory`, `create_directory`, `delete_file`, `move_file`, `file_search` | Full local filesystem operations with sandbox directory boundary awareness. | `read_*` / `list_*`: Low<br>`write_*` / `delete_*`: High |
| **Execution** | `run_shell_command`, `run_applescript` | Runs shell commands in zsh and AppleScript/OSA automation scripts. | High |
| **System & UI** | `control_app`, `control_accessibility`, `control_browser`, `take_screenshot`, `get_system_info`, `get_running_processes`, `get_frontmost_app` | Desktop UI automation, browser DOM manipulation, system diagnostics, and screenshot capture. | Control: High<br>Get/Inspect: Low |
| **Vision** | `analyze_image`, `detect_image_text` | Image analysis and Apple Vision OCR text detection. | Medium |
| **Clipboard** | `read_clipboard`, `write_clipboard` | System pasteboard read and write. | Read: Low<br>Write: Medium |
| **Memory & Plan** | `store_memory`, `search_memory`, `update_plan` | Semantic vector / keyword memory storage, retrieval, and task plan step management. | Medium |
| **Multi-Agent** | `delegate_task`, `convene_meeting` | Task delegation to sub-agents and multi-agent panel debate convening. | Medium |
| **Extensibility** | `create_skill`, `run_workflow`, `execute_dynamic_tool` | Dynamic skill script creation in `~/.apex/skills`, workflow execution, and dynamic tool calls. | Skill: High<br>Run: Medium |
| **Integrations** | `web_search`, `send_notification`, `audit_projects`, `daily_briefing`, `weekly_reflection`, `spotlight_search` | DuckDuckGo web search, macOS user notifications, project health auditing, briefing generators, Spotlight queries. | Notification/Search: Medium<br>Audit: Low |
| **Code Review** | `save_review_session`, `list_review_sessions`, `confirm_completion` | Code review persistence and task completion confirmation. | Low / Medium |

---

### 5.2 Dynamic Toolbox & Model Context Protocol (MCP)
- **`DynamicToolbox` (`DynamicToolbox.swift`)**:
  - Automatically loads custom JSON/YAML tool manifests from `~/.apex/tools` and `~/.apex/skills`.
  - Uses `DispatchSourceFileSystemObject` to watch directories for live reloading without app restarts.
- **MCP Integration (`MCPManager.swift` & `MCPClient.swift`)**:
  - Connects to external MCP servers (via stdio or SSE).
  - Dynamically registers tool definitions and routes tool calls to external MCP client instances.

---

### 5.3 Safety, Sandbox & Security Verification

1. **Risk Classification (`AgentSecurity.swift`)**:
   - 3-tier risk classification: `.low` (read-only), `.medium` (external fetch/state update), `.high` (destructive, command execution, UI control).
   - High-risk tools require explicit confirmation unless authorized by approval policy.

2. **Approval Policy & Destructive Backstop (`ApprovalPolicy.swift`)**:
   - Regex-based backstop blocking unattended/auto-execution of destructive patterns:
     - Shell commands: `rm -rf`, `mkfs`, `diskutil erase`, `dd of=/dev/`, `shutdown`, `reboot`, fork bombs (`:(){ :|:& };:`), `git push --force`, `git reset --hard`, `sudo rm`, `chmod -R 777 /`.
     - Sensitive paths/credentials: `.env`, `.ssh/`, `id_rsa`, `id_ed25519`, `.aws/credentials`, `.netrc`, `keychain`, `credentials.json`.
   - Narrowed command grants: grants are program-scoped (`run_shell_command:git`, `run_shell_command:npm`) rather than opening a blanket shell grant.

3. **File Rollback Safety Net (`FileRollback.swift`)**:
   - Before any destructive file operation, creates a snapshot at `<path>.apex-bak`.
   - Provides instant recovery (`FileRollback.rollback(path:)`) if an agent edit is rejected or corrupted.

4. **Indirect Prompt Injection Defense (`Tool+Logging.swift`)**:
   - Sanitizes tool results against instruction override patterns:
     - `ignore previous instructions`, `disregard the system prompt`
     - `you are now...` role hijack attempts
     - `system prompt:`, `new instructions:`
     - Fenced system code blocks (```system`)
   - Neutralizes matched strings with `[PROMPT-INJECTION-FLAGGED: ...]` markers before returning data into model transcripts.
   - Central output length truncation capped at 3,000 characters.

5. **App-Wide Tool Kill-Switch (`ToolPolicy.swift`)**:
   - Global allowlist/denylist persisted in `UserDefaults` (`apex.disabledTools`) allowing app-wide disablement of tools regardless of individual agent permissions.

6. **Persistent Security Audit Log (`AgentAuditLog.swift`)**:
   - Records every tool invocation timestamp, tool name, arguments, confirmation status, and outcome.

---

## 6. Synthesis & Evaluation Findings

| Subsystem | Architectural Strengths | Key Constraints / Noted Nuances |
| :--- | :--- | :--- |
| **Bot Roster** | Durable SwiftData persistence; clean separation of shared Computer vs isolated Bot memories; live Chief of Staff roster interpolation with truncation bounds. | Bot sessions share underlying orchestrator SwiftData modelContext; Chief roster caps bots to 40 entries. |
| **LLM Engines** | Unified Swift API for native, local, and cloud models; WWDC26 executor conformances; direct HTTP engines bypass OS beta channel pump crashes; runtime dlsym multimodal protection. | macOS 27 beta 4 direct FoundationModels stream hangs require `respond(to:)` direct call; MLX requires running server at `http://127.0.0.1:8080`. |
| **Multi-Agent Coordination** | Flexible triple-modality (Group Chat, Task Delegation, Panel Meeting); robust safety guards (`TurnWatchdog`, `RepeatDetector`, `PeerApproval`, `StateGraph`); full Instruments and TraceBus observability. | Group chats are currently ephemeral in memory; sub-agent delegation depth is strictly capped at 2. |
| **Tool Registry & Dispatch** | 30+ native tools; dynamic script & MCP tool loading with filesystem watcher; 10-point defense-in-depth safety pipeline (Actor isolation, 3-tier risk, regex destructive guard, .apex-bak rollback, prompt injection scrubber). | High-risk tools require user confirmation unless matching an explicit program-scoped grant. |

---
**Report Status**: Complete  
**Artifact Location**: `/Users/danielstevens/Developer/ApexAgent/.agents/teamwork_preview_explorer_survey_2/survey_report.md`
